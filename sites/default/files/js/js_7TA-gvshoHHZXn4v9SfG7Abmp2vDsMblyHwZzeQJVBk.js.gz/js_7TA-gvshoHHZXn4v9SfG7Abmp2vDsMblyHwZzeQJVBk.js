Drupal.locale = { 'pluralFormula': function ($n) { return Number(($n>1)); }, 'strings': {"":{"An AJAX HTTP error occurred.":"Une erreur HTTP AJAX s\u0027est produite.","HTTP Result Code: !status":"Code de statut HTTP : !status","An AJAX HTTP request terminated abnormally.":"Une requ\u00eate HTTP AJAX s\u0027est termin\u00e9e anormalement.","Debugging information follows.":"Informations de d\u00e9bogage ci-dessous.","Path: !uri":"Chemin : !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseText : !responseText","ReadyState: !readyState":"ReadyState : !readyState","CustomMessage: !customMessage":"Message personalis\u00e9 : !customMessage","Previous":"Pr\u00e9c\u00e9dent","Next":"Suivant","Close":"Fermer","Pause Slideshow":"Arr\u00eater le diaporama","Play Slideshow":"D\u00e9marrer le diaporama","No results":"Aucun r\u00e9sultat","All":"Tout","New":"Nouveau","Recent":"R\u00e9cent","required":"requis","Re-order rows by numerical weight instead of dragging.":"R\u00e9-ordonner les lignes avec des poids num\u00e9riques plut\u00f4t qu\u0027en les d\u00e9pla\u00e7ant.","Show row weights":"Afficher le poids des lignes","Hide row weights":"Cacher le poids des lignes","Drag to re-order":"Cliquer-d\u00e9poser pour r\u00e9-organiser","Changes made in this table will not be saved until the form is submitted.":"Les changements effectu\u00e9s dans ce tableau ne seront pris en compte que lorsque la configuration aura \u00e9t\u00e9 enregistr\u00e9e.","Hide":"Masquer","Show":"Afficher","Also allow !name role to !permission?":"Autoriser \u00e9galement le r\u00f4le !name \u00e0 !permission ?","Cancel":"Annuler","Disabled":"D\u00e9sactiv\u00e9","Enabled":"Activ\u00e9","Content can only be inserted into CKEditor in the WYSIWYG mode.":"Le contenu peut seulement \u00eatre ins\u00e9r\u00e9 dans CKEditor en mode WYSIWYG.","Edit":"Modifier","From @title":"Depuis @title","To @title":"A\u0300 @title","Owned by @name":"D\u00e9tenu par @name","Created @date":"Cr\u00e9\u00e9(e) le @date","New order":"Nouvelle commande","Updated @date":"Mis(e) \u00e0 jour le @date","Add":"Ajouter","Configure":"Configurer","Loading...":"En cours de chargement...","none":"aucun(e)","Upload":"Transf\u00e9rer","Done":"Termin\u00e9","OK":"OK","This field is required.":"Ce champ est requis.","Select all rows in this table":"S\u00e9lectionner toutes les lignes du tableau","Deselect all rows in this table":"D\u00e9s\u00e9lectionner toutes les lignes du tableau","Not published":"Non publi\u00e9","Please wait...":"Veuillez patienter...","Only files with the following extensions are allowed: %files-allowed.":"Seuls les fichiers se terminant par les extensions suivantes sont autoris\u00e9s\u00a0: %files-allowed.","By @name on @date":"Par @name le @date","By @name":"Par @name","Not in menu":"Pas dans le menu","Alias: @alias":"Alias : @alias","No alias":"Aucun alias","New revision":"Nouvelle r\u00e9vision","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"N\u0027oubliez pas de cliquer sur \u003Cem\u003EEnregistrer les blocs\u003C\/em\u003E pour confirmer les modifications apport\u00e9es ici.","This permission is inherited from the authenticated user role.":"Ce droit est h\u00e9rit\u00e9e du r\u00f4le de l\u0027utilisateur authentifi\u00e9.","No revision":"Aucune r\u00e9vision","@number comments per page":"@number commentaires par page","Requires a title":"Titre obligatoire","Not restricted":"Non restreint","(active tab)":"(onglet actif)","Not customizable":"Non personnalisable","Restricted to certain pages":"R\u00e9serv\u00e9 \u00e0 certaines pages","The block cannot be placed in this region.":"Le bloc ne peut pas \u00eatre plac\u00e9 dans cette r\u00e9gion.","Customize dashboard":"Personnaliser le tableau de bord","Hide summary":"Masquer le r\u00e9sum\u00e9","Edit summary":"Modifier le r\u00e9sum\u00e9","Don\u0027t display post information":"Ne pas afficher les informations de la contribution","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"Le fichier s\u00e9lectionn\u00e9 %filename ne peut pas \u00eatre transf\u00e9r\u00e9. Seulement les fichiers avec les extensions suivantes sont permis : %extensions.","Autocomplete popup":"Popup d\u0027auto-compl\u00e9tion","Searching for matches...":"Recherche de correspondances...","The response failed verification so will not be processed.":"La v\u00e9rification de la r\u00e9ponse a \u00e9chou\u00e9, elle ne sera pas trait\u00e9e.","The callback URL is not local and not trusted: !url":"L\u0027URL de retour n\u0027est pas locale et n\u0027est pas de confiance : !url","all":"tout","Submit":"Soumettre","No flags":"Aucun flag","Please select a file.":"Veuillez s\u00e9lectionner un fichier.","You are not allowed to operate on more than %num files.":"Vous n\u0027\u00eates pas autoris\u00e9(e) \u00e0 effectuer des op\u00e9rations sur plus de %num fichiers.","Please specify dimensions within the allowed range that is from 1x1 to @dimensions.":"Veuillez sp\u00e9cifier des dimensions dans la plage autoris\u00e9e, soit de 1x1 \u00e0 @dimensions.","%filename is not an image.":"%filename n\u0027est pas une image.","Insert file":"Ins\u00e9rer un fichier","Change view":"Changer la vue","Show description":"Afficher la description","Hide description":"Masquer la description","Add file":"Ajouter un fichier","Select":"S\u00e9lectionner","Media browser":"Navigateur de m\u00e9dias","If you switch views, you will lose your selection.":"Si vous changez les vues, vous allez perdre votre s\u00e9lection.","Cannot continue, nothing selected":"Impossible de continuer, rien n\u0027est s\u00e9lectionn\u00e9","Error getting media.":"Erreur d\u0027obtention du m\u00e9dia.","There is nothing in your media library. Select the Upload tab above to add a file.":"Il n\u0027y a rien dans votre biblioth\u00e8que de m\u00e9dias. S\u00e9lectionnez l\u0027onglet Transf\u00e9rer ci-dessus pour ajouter un fichier.","Ignored from settings":"Ignor\u00e9 volontairement","Automatic alias":"Alias automatique","Available tokens":"Jetons (tokens) disponibles","Insert this token into your form":"Ins\u00e9rer ce jeton (\u003Cem\u003Etoken\u003C\/em\u003E) dans votre formulaire","First click a text field to insert your tokens into.":"Cliquez d\u0027abord sur un champ de texte pour ins\u00e9rer vos jetons (\u003Cem\u003Etokens\u003C\/em\u003E) dans celui -ci.","Loading token browser...":"Chargement de l\u0027explorateur de jetons...","Remove group":"Supprimer le groupe","Apply (all displays)":"Appliquer (tous les affichages)","Apply (this display)":"Appliquer (cet affichage)","Revert to default":"R\u00e9tablir par d\u00e9faut","You can not perform this operation.":"Vous ne pouvez pas r\u00e9aliser cette op\u00e9ration.","Do you want to refresh the current directory?":"Souhaitez-vous rafra\u00eechir le r\u00e9pertoire courant ?","Delete selected files?":"Voulez-vous vraiment supprimer les fichiers s\u00e9lectionn\u00e9s ?","Please select a thumbnail.":"Veuillez s\u00e9lectionner une vignette.","Log messages":"Journaliser les messages","You must select at least %num files.":"Vous devez s\u00e9lectionner au moins %num fichier(s).","@label: @value":"@label: @value","Using defaults":"Utiliser les param\u00e8tres par d\u00e9faut.","No redirects":"Aucune redirection","Inclusion: @value":"Inclusion : @value","Priority: @value":"Priorit\u00e9 : @value","Click update to save the configuration":"Cliquer sur \u0022Mettre \u00e0 jour\u0022 pour enregistrer la configuration","Pause":"Pause","Resume":"Reprendre","Update Advanced Option":"Mettre \u00e0 jour l\u0027Option Avanc\u00e9e","Applied Options":"Options appliqu\u00e9es","There was no action specified.":"Il n\u0027y avait pas d\u0027action sp\u00e9cifi\u00e9e.","An invalid integer was specified for slideNum.":"Un entier invalide \u00e9tait sp\u00e9cifi\u00e9 pour slideNum.","An invalid action \u0022!action\u0022 was specified.":"Une action invalide \u0022!action\u0022 \u00e9tait sp\u00e9cifi\u00e9e.","Colorbox":"Colorbox","Downloads":"T\u00e9l\u00e9chargements","Destination: @scheme":"Destination : @scheme","Associated with @name":"Associ\u00e9 \u00e0 @name","One domain with multiple subdomains":"Un domaine avec plusieurs sous-domaines","Multiple top-level domains":"Plusieurs domaines de premier niveau","Universal web tracking opt-out":"Refus global du suivi sur le web","All pages with exceptions":"Toutes les pages avec exceptions","Excepted: @roles":"Except\u00e9 : @roles","On by default with opt out":"Activ\u00e9 par d\u00e9faut avec le refus du suivi","Off by default with opt in":"D\u00e9sactiv\u00e9 par d\u00e9faut avec l\u0027acceptation du suivi","Outbound links":"Liens sortants","Mailto links":"Liens mailto","Not tracked":"Non suivi","@items enabled":"@items activ\u00e9(s)","Site search":"Recherche du site","AdSense ads":"Annonces AdSense","Display features":"Fonctions d\u0027affichage","A single domain":"Un seul domaine","Anonymize IP":"Rendre l\u0027IP anonyme","No privacy":"Pas de confidentialit\u00e9"}} };;
/*
 * jQuery.appear
 * https://github.com/bas2k/jquery.appear/
 * http://code.google.com/p/jquery-appear/
 *
 * Copyright (c) 2009 Michael Hixson
 * Copyright (c) 2012 Alexander Brovikov
 * Licensed under the MIT license (http://www.opensource.org/licenses/mit-license.php)
 */
(function($) {
    $.fn.appear = function(fn, options) {

        var settings = $.extend({

            //arbitrary data to pass to fn
            data: undefined,

            //call fn only on the first appear?
            one: true,

            // X & Y accuracy
            accX: 0,
            accY: 0

        }, options);

        return this.each(function() {

            var t = $(this);

            //whether the element is currently visible
            t.appeared = false;

            if (!fn) {

                //trigger the custom event
                t.trigger('appear', settings.data);
                return;
            }

            var w = $(window);

            //fires the appear event when appropriate
            var check = function() {

                //is the element hidden?
                if (!t.is(':visible')) {

                    //it became hidden
                    t.appeared = false;
                    return;
                }

                //is the element inside the visible window?
                var a = w.scrollLeft();
                var b = w.scrollTop();
                var o = t.offset();
                var x = o.left;
                var y = o.top;

                var ax = settings.accX;
                var ay = settings.accY;
                var th = t.height();
                var wh = w.height();
                var tw = t.width();
                var ww = w.width();

                if (y + th + ay >= b &&
                    y <= b + wh + ay &&
                    x + tw + ax >= a &&
                    x <= a + ww + ax) {

                    //trigger the custom event
                    if (!t.appeared) t.trigger('appear', settings.data);

                } else {

                    //it scrolled out of view
                    t.appeared = false;
                }
            };

            //create a modified fn with some additional logic
            var modifiedFn = function() {

                //mark the element as visible
                t.appeared = true;

                //is this supposed to happen only once?
                if (settings.one) {

                    //remove the check
                    w.unbind('scroll', check);
                    var i = $.inArray(check, $.fn.appear.checks);
                    if (i >= 0) $.fn.appear.checks.splice(i, 1);
                }

                //trigger the original fn
                fn.apply(this, arguments);
            };

            //bind the modified fn to the element
            if (settings.one) t.one('appear', settings.data, modifiedFn);
            else t.bind('appear', settings.data, modifiedFn);

            //check whenever the window scrolls
            w.scroll(check);

            //check whenever the dom changes
            $.fn.appear.checks.push(check);

            //check now
            (check)();
        });
    };

    //keep a queue of appearance checks
    $.extend($.fn.appear, {

        checks: [],
        timeout: null,

        //process the queue
        checkAll: function() {
            var length = $.fn.appear.checks.length;
            if (length > 0) while (length--) ($.fn.appear.checks[length])();
        },

        //check the queue asynchronously
        run: function() {
            if ($.fn.appear.timeout) clearTimeout($.fn.appear.timeout);
            $.fn.appear.timeout = setTimeout($.fn.appear.checkAll, 20);
        }
    });

    //run checks when these methods are called
    $.each(['append', 'prepend', 'after', 'before', 'attr',
        'removeAttr', 'addClass', 'removeClass', 'toggleClass',
        'remove', 'css', 'show', 'hide'], function(i, n) {
        var old = $.fn[n];
        if (old) {
            $.fn[n] = function() {
                var r = old.apply(this, arguments);
                $.fn.appear.run();
                return r;
            }
        }
    });

})(jQuery);;
jQuery(document).ready(function($) {
    $(".dexp-animate").each(function() {
        var $this = $(this);
        var animate_class = $this.data('animate'), delay = $this.data('animate-delay') || 0;
        delay = delay + 50;
        $this.appear(function() {
            setTimeout(function() {
                $this.addClass('animated').addClass(animate_class);
                $this.unbind('appear');
            }, delay);
        }, {
            accX: 0,
            accY: 0,
            one: false
        });
    });
})
;
