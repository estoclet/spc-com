/**
 * @file
 * Views Slideshow Xtra Javascript.
 */
(function ($) {
  Drupal.viewsSlideshowXtra = Drupal.viewsSlideshowXtra || {};
  var pageX = 0, pageY = 0, timeout;
  Drupal.viewsSlideshowXtra.transitionBegin = function (options) {

    // Find our views slideshow xtra elements
    $('[id^="views-slideshow-xtra-"]:not(.views-slideshow-xtra-processed)').addClass('views-slideshow-xtra-processed').each(function() {

      // Get the slide box.
      var slideArea = $(this).parent().parent().find('.views_slideshow_main');

      // Remove the views slideshow xtra html from the dom
      var xtraHTML = $(this).detach();

      // Attach the views slideshow xtra html to below the main slide.
      $(xtraHTML).appendTo(slideArea);

      // Get the offsets of the slide and the views slideshow xtra elements
      var slideAreaOffset = slideArea.offset();
      var xtraOffset = $(this).offset();

      // Move the views slideshow xtra element over the top of the slide.
      var marginMove = slideAreaOffset.top - xtraOffset.top;
      $(this).css({'margin-top': marginMove + 'px'});

      // Move type=text slide elements into place.
      var slideData = Drupal.settings.viewsSlideshowXtra[options.slideshowID].slideInfo.text;
      var slideNum = 0;
      for (slide in slideData) {
        var items = slideData[slide];
        var itemNum = 0;
        for (item in items) {
          //alert('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-text-' + slideNum + '-' + itemNum);
          $('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-text-' + slideNum + '-' + itemNum).css({
            'width': slideArea.width()
          });
          itemNum++;
        }
        slideNum++;
      }

      // Move type=link slide elements into place.
      var slideData = Drupal.settings.viewsSlideshowXtra[options.slideshowID].slideInfo.link;
      var slideNum = 0;
      for (slide in slideData) {
        var items = slideData[slide];
        var itemNum = 0;
        for (item in items) {
          //alert('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-link-' + slideNum + '-' + itemNum);
        	$('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-link-' + slideNum + '-' + itemNum).css({
            'width': slideArea.width()
          });
          itemNum++;
        }
        slideNum++;
      }

      // Move type=image slide elements into place.
      var slideData = Drupal.settings.viewsSlideshowXtra[options.slideshowID].slideInfo.image;
      var slideNum = 0;
      for (slide in slideData) {
        var items = slideData[slide];
        var itemNum = 0;
        for (item in items) {
          //alert('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-image-' + slideNum + '-' + itemNum);
        	$('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-image-' + slideNum + '-' + itemNum).css({
            'width': slideArea.width()
          });
          itemNum++;
        }
        slideNum++;
      }

      var settings = Drupal.settings.viewsSlideshowXtra[options.slideshowID];
	    if (settings.pauseAfterMouseMove) {
	    //if(true) {
	    	slideArea.mousemove(function(e) {
      	  if (pageX - e.pageX > 5 || pageY - e.pageY > 5) {
      	  	Drupal.viewsSlideshow.action({ "action": 'pause', "slideshowID": options.slideshowID });
      	    clearTimeout(timeout);
      	    timeout = setTimeout(function() {
      	    		Drupal.viewsSlideshow.action({ "action": 'play', "slideshowID": options.slideshowID });
      	    		}, 2000);
      	  }
      	  pageX = e.pageX;
      	  pageY = e.pageY;
	    	});
	    }

    });

    // TODO Find a better way to detect if xtra module is enabled but this is not
    // an xtra slideshow.  This seems to work but its probably not the right way.
    //if (Drupal.settings.viewsSlideshowXtra[options.slideshowID]) { THIS DOES NOT WORK!
    if ('viewsSlideshowXtra' in Drupal.settings) {
	    var settings = Drupal.settings.viewsSlideshowXtra[options.slideshowID];

	    // Hide elements either by fading or not
	    if (settings.displayDelayFade) {
	      $('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-row').fadeOut();
	    }
	    else {
	      $('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-row').hide();
	    }

      settings.currentTransitioningSlide = options.slideNum;

	    // Pause from showing the text and links however long the user decides.
	    setTimeout(function() {
        if (options.slideNum == settings.currentTransitioningSlide) {
          if (settings.displayDelayFade) {
            $('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-row-' + options.slideNum).fadeIn();
          }
          else {
            $('#views-slideshow-xtra-' + options.slideshowID + ' .views-slideshow-xtra-row-' + options.slideNum).show();
          }
        }
	    },
	    settings.displayDelay
	    );

    }
  };
})(jQuery);

/*
*/
;
/**
 * @file
 * General extensions to Content Analysis.
 */
var contentanalysis = contentanalysis || {};

(function ($, $$) {
  $.extend($$, {
    contentanalysisPrevAnalyzerTab: '',
    contentanalysisPrevReportTab: '',
    contentanalysisCurrentAnalyzerTab: '',
    contentanalysisCurrentReportTab: '',
    contentanalysisReportActiveTab: {},

    init: function () {
      $$.contentanalysis_contentanalysisui();
    },

    contentanalysis_contentanalysisui: function () {
      if ($('#modalContent div.analyzers h3.analyzer').size() > 0) {
        $$.contentanalysis_show_analyzer_tab($('div.analyzers h3.analyzer').get(0));
        $('div.analyzers h3.analyzer').mousedown(function () {
          $$.contentanalysis_show_analyzer_tab(this);
        });
        $('h3.contentanalysis-report-tab').mousedown(function () {
          $$.contentanalysis_show_report_tab(this);
        });
      }
    },

    contentanalysis_back: function () {
      if ($$.contentanalysisPrevAnalyzerTab) {
        $$.contentanalysis_show_analyzer_tab($$.contentanalysisPrevAnalyzerTab);
      }
      //contentanalysis_show_report_tab(contentanalysisPrevReportTab);
    },

    contentanalysis_show_analyzer_tab: function (theTab) {
      $('div.analysis-results div.analyzer-analysis:eq(' + $('.analyzers h3.analyzer').index(theTab) + ')').children('.content-analysis-tab:first').addClass('active');
      $('div.analysis-results div.analyzer-analysis').hide();
      $('.analyzers h3.analyzer').removeClass('active');
      $(theTab).addClass('active');
      $('div.analysis-results div.analyzer-analysis:eq(' + $('.analyzers h3.analyzer').index(theTab) + ')').show();
      $('.content-analysis-results').hide();

      var id = $(theTab).attr('id');
      var e = id.split('-');
      var analyzer = e[3];

      if ($$.contentanalysisReportActiveTab[analyzer]) {
        $$.contentanalysis_show_report_tab($('#contentanalysis-report-tab-' + analyzer + '-' + $$.contentanalysisReportActiveTab[analyzer]));
      }
      else {
        $$.contentanalysis_show_report_tab($('#contentanalysis-report-tab-' + analyzer + '-0'));
      }
      $$.contentanalysisPrevAnalyzerTab = $$.contentanalysisCurrentAnalyzerTab;
      $$.contentanalysisCurrentAnalyzerTab = theTab;
    },

    contentanalysis_show_report_tab: function (theTab) {
      var id = $(theTab).attr('id');
      var e = id.split('-');
      $$.contentanalysisReportActiveTab[e[3]] = e[4];
      $('h3.contentanalysis-report-tab').removeClass('active');
      $(theTab).addClass('active');
      $('.contentanalysis-results-section').hide();

      var tabs = $("#contentanalysis-report-tabs-" + e[3]);
      //tabs.css('border','2px solid red');
      var pos = $("#contentanalysis-report-tabs-" + e[3]).position();
      var offset = $("#contentanalysis-report-tabs-" + e[3]).offset();
      var height = tabs.height();
      var top = (pos.top + height) + "px";
      var left = (pos.left) + "px";

      var sec_id = id.replace('tab', 'results');
      var result_id = sec_id.replace('-' + e[4], '');
      //$('#' + result_id).css({'top': top, 'left': left});
      $('#' + result_id).css('top', top);
      //$('#' + result_id).css('border', '2px solid green');
      $('#' + sec_id).show();
      //alert("pos.left="+pos.left+",pos.top="+pos.top+",offset.left="+offset.left+",offset.top="+offset.top);
      $$.contentanalysisPrevReportTab = $$.contentanalysisCurrentReportTab;
      $$.contentanalysisCurrentReportTab = theTab;
    },

    // called from inline Analyze content button
    contentanalysis_inline_analysis: function () {
      Drupal.settings.contentanalysis.display_dialog = 0;
      Drupal.settings.contentanalysis.display_inline = 1;
      //$('#contentanalysis-ininline-analysis-button').after('<span class="throbber">Loading...</span>');
      //$('#contentanalysis-ininline-analysis-button').after(Drupal.settings.contentanalysis.throbber);
      $('#contentanalysis-buttons').after('<div class="ahah-progress ahah-progress-throbber"><div class="throbber">&nbsp;</div><div class="message">' + Drupal.t('Analyzing...') + '</div></div>');
      $$.contentanalysis_analyze();
    },

    // called from inline Analyze content button
    contentanalysis_dialog_analysis: function () {
      Drupal.settings.contentanalysis.display_dialog = 1;
      Drupal.settings.contentanalysis.display_inline = 0;
      $$.contentanalysis_analyze();
    },

    // called from inline Analyze content button
    contentanalysis_full_analysis: function () {
      Drupal.settings.contentanalysis.display_dialog = 1;
      Drupal.settings.contentanalysis.display_inline = 1;

      $$.contentanalysis_analyze();
    },

    // called from inline Analyze content button
    contentanalysis_refresh_analysis: function (analyzer) {
      Drupal.settings.contentanalysis.display_dialog = 0;
      Drupal.settings.contentanalysis.display_inline = 1;
      //$('.contentanalysis-refresh-link-' + analyzer).replaceWith('<span class="throbber">Loading...</span>');
      $('.contentanalysis-refresh-link-' + analyzer).replaceWith('<div class="ahah-progress ahah-progress-throbber"><div class="throbber">&nbsp;</div></div>');
      $$.contentanalysis_analyze(analyzer);
    },

    contentanalysis_analyze: function (analyzer_override) {
      // Get node language.
      var lang;
      lang = (Drupal.settings.contentanalysis.language) ? Drupal.settings.contentanalysis.language : "und";

      // if TinyMCE is used, turn off and on to save body text to textarea
      var data = {
        'nid': -1,
        'node_type': -1,
        'source': -1,
        'analyzers': -1,
        'title': -1,
        'body': -1,
        'body_summary': -1,
        'page_title': -1,
        'meta_title': -1,
        'meta_keywords': -1,
        'meta_description': -1,
        'path_alias': -1,
        'path_pathauto': -1,
        'url': -1,
        'page': -1,
        'body_input_filter': -1,
        'hidden': -1,
        'code': Drupal.settings.contentanalysis.code,
        'action': -1
      };
      if (analyzer_override) {
        data.action = 'refresh';
      }

      if ($('#contentanalysis-page-analyzer-form').html()) {
        data.source = 'admin-form';
        data.body = $('[name=input]').val();
        data.nid = $('[name=input_nid]').val();
        data.url = $('[name=input_url]').val();
        if (data.body == '') {
          data.body = -1;
        }
        if (data.nid == '') {
          data.nid = -1;
        }
        if (data.url == '') {
          data.url = -1;
        }
      } else if ($('.node-form').html()) {
        data.source = 'node-edit-form';
        // Turn off TinyMCE if enabled
        if (typeof tinyMCE == 'object') {
          tinyMCE.get('edit-body-'+lang+'-0-value').hide();
        }
        // Turn off CKEditor if any.
        var ckeditor = false;
        if ($('#cke_edit-body-'+lang+'-0-value').html()) {
          //$('#wysiwyg-toggle-edit-body-'+lang+'-0-value').click();
          $('#switch_edit-body-'+lang+'-0-value').click();
          ckeditor = true;
        }

        data.title = $('#edit-title').val();
        data.body = $('#edit-body-'+lang+'-0-value').val();
        if ($('#edit-body-'+lang+'-0-summary').val() != null) {
          data.body_summary = $('#edit-body-'+lang+'-0-summary').val();
        }
        data.nid = Drupal.settings.contentanalysis.nid;
        data.node_type = Drupal.settings.contentanalysis.node_type;
        data.body_input_filter = $("select[name='body['+lang+'][0][format]'] option:selected").val();

        if ($('#edit-page-title').val() != null) {
          data.page_title = $('#edit-page-title').val();
        }
        // check if metatag module fields exist
        if ($('#edit-metatags-title-value').val() != null) {
          data.meta_title = $('#edit-metatags-title-value').val();
        }
        if ($('#edit-metatags-keywords-value').val() != null) {
          data.meta_keywords = $('#edit-metatags-keywords-value').val();
        }
        if ($('#edit-metatags-description-value').val() != null) {
          data.meta_description = $('#edit-metatags-description-value').val();
        }
        if ($('#edit-path-alias').val() != null) {
          data.url = window.location.host + Drupal.settings.contentanalysis.base_path + $('#edit-path-alias').val();
          data.path_alias = $('#edit-path-alias').val();
        }
        if ($("input[name='path[pathauto]']:checked").val() != null) {
          data.path_pathauto = 1;
        }
        // Turn back on tinyMCE
        if (typeof tinyMCE == 'object') {
          tinyMCE.get('edit-body-'+lang+'-0-value').show();
        }
        // Turn back on CKEditor if needed.
        if (ckeditor) {
          //$('#wysiwyg-toggle-edit-body-'+lang+'-0-value').click();
          $('#switch_edit-body-'+lang+'-0-value').click();
        }

      } else {
        data.source = 'page-link';
        data.page = $('html').html();
        data.url = window.location.href;
      }
      if (Drupal.settings.contentanalysis.hidden != null) {
        data.hidden = Drupal.settings.contentanalysis.hidden;
      }

      //alert('data.nid ' + data.nid)
      var analyzers_arr = [];
      if (analyzer_override) {
        data.analyzers = analyzer_override;
        analyzers_arr[0] = data.analyzers;
      }
      else if ($('#contentanalysis_analyzers_override input').val() != null) {
        data.analyzers = $('#contentanalysis_analyzers_override input').val();
        analyzers_arr[0] = data.analyzers;
      }
      else {
        var i = 0;
        $('#contentanalysis_analyzers .form-checkbox:checked').each(function () {
          var expr = new RegExp(/\[[^\]]+\]/);
          analyzers_arr[i] = expr.exec($(this).attr('name'))[0].replace(']', '').replace('[', '');
          i++;
        });
        data.analyzers = analyzers_arr.join(',');
      }
      // Call contentanalysis_data for enabled analyzers.
      for (var i in analyzers_arr) {
        var aid = analyzers_arr[i];
        var module = Drupal.settings.contentanalysis.analyzer_modules[aid].module;
        if (eval('typeof ' + module + '_contentanalysis_data == "function"')) {
          d = eval(module + '_contentanalysis_data')(aid, data);
          for (var k in d) {
            eval('data.ao_' + aid + '_' + k + ' = "' + d[k] + '";');
          }
        }
      }
      $('#contentanalysis-buttons').hide();
      $.ajax({
        type: 'POST',
        url: Drupal.settings.contentanalysis.analyze_callback,
        data: data,
        dataType: 'json',
        success: function (data, textStatus) {
          analyzers_arr = data.inputs['analyzers'].split(",");
          if (Drupal.settings.contentanalysis.display_dialog == 1) {
            $('#analysis-modal').append(data.main['output']);
            $('#analysis-modal .progress').remove();
            //Drupal.behaviors.contentanalysisui();
            $$.contentanalysis_contentanalysisui();
          }
          // display inline if enabled
          if (Drupal.settings.contentanalysis.display_inline == 1) {
            if (data.inputs['action'] == 'refresh') {
              //if($('.contentanalysis_section_analysis').length > 0)
              for (i in analyzers_arr) {
                aid = analyzers_arr[i];
                $('.contentanalysis-report-' + aid + '-page_title').replaceWith(data.page_title['output']);
                $('.contentanalysis-report-' + aid + '-body').replaceWith(data.body['output']);
                $('.contentanalysis-report-' + aid + '-meta_description').replaceWith(data.meta_description['output']);
                $('.contentanalysis-report-' + aid + '-meta_keywords').replaceWith(data.meta_keywords['output']);
              }
            }
            else {
              var show_title = true;
              if ($('.form-item-metatags-title-value').length > 0) {
                $('.form-item-metatags-title-value > .contentanalysis_section_analysis').remove();
                $('.form-item-metatags-title-value').append(data.page_title['output']);
                // check if metatag-title contains [node:title] token
                if ($('#edit-metatags-title-value').val() != null) {
                  var meta_title = $('#edit-metatags-title-value').val();
                  if (meta_title.indexOf("[node:title]") == -1) {
                    //show_title = false;
                  }
                }
              }
              if (show_title) {
                $('.form-item-title > .contentanalysis_section_analysis').remove();
                $('.form-item-title').append(data.page_title['output']);
              }

              $('#edit-body > .contentanalysis_section_analysis').remove();
              $('#edit-body').append(data.body['output']);
              // check newer nodewords format
              if (($('.form-item-metatags-description-value').length > 0) && data.meta_description != null) {
                $('.form-item-metatags-description-value > .contentanalysis_section_analysis').remove();
                $('.form-item-metatags-description-value').append(data.meta_description['output']);
              }

              if (($('.form-item-metatags-keywords-value').length > 0) && data.meta_keywords != null) {
                $('.form-item-metatags-keywords-value > .contentanalysis_section_analysis').remove();
                $('.form-item-metatags-keywords-value').append(data.meta_keywords['output']);
              }
            }
            for (var i in analyzers_arr) {
              var aid = analyzers_arr[i];
              h = '<a href="#" class="contentanalysis-refresh-link-' + aid + '" onclick="contentanalysis.contentanalysis_refresh_analysis(\'' + aid + '\'); return false;">';
              h += '<img src="' + Drupal.settings.contentanalysis.path_to_module + '/icons/refresh.png" alt="refresh" />';
              h += '</a>';
              $('.contentanalysis-report-' + aid + ' label').append(h);
            }
          }
          // call any modules post analysis hooks
          for (var i in analyzers_arr) {
            var aid = analyzers_arr[i];
            var module = Drupal.settings.contentanalysis.analyzer_modules[aid].module;
            if (eval('typeof ' + module + '_contentanalysis_analysis_success == "function"')) {
              eval(module + '_contentanalysis_analysis_success')(aid, data);
            }
          }
          if (typeof Drupal.behaviors.collapse == 'function') {
            Drupal.behaviors.collapse();
          }
          $('.ahah-progress-throbber').remove();
          $('#contentanalysis-buttons').show();
        },
        error: function (xhr, status) {
          alert(xhr.responseText.toString());
          $('.ahah-progress-throbber').remove();
          $('#contentanalysis-buttons').show();
        }
      });
      return false;
    }
  });

  Drupal.behaviors.contentanalysisui = {
    attach: function (context, settings) {
      $$.init();
    }
  };

  Sliders = {};

  Sliders.changeHandle = function (e, ui) {
    var id = jQuery(ui.handle).parents('div.slider-widget-container').attr('id');
    if (typeof(ui.values) != 'undefined') {
      jQuery.each(ui.values, function (i, val) {
        jQuery("#" + id + "_value_" + i).val(val);
        jQuery("#" + id + "_nr_" + i).text(val);
      });
    } else {
      jQuery("#" + id + "_value_0").val(ui.value);
      jQuery("#" + id + "_nr_0").text(ui.value);
    }
  };

})(jQuery, contentanalysis);
;
(function ($) {

/**
 * A progressbar object. Initialized with the given id. Must be inserted into
 * the DOM afterwards through progressBar.element.
 *
 * method is the function which will perform the HTTP request to get the
 * progress bar state. Either "GET" or "POST".
 *
 * e.g. pb = new progressBar('myProgressBar');
 *      some_element.appendChild(pb.element);
 */
Drupal.progressBar = function (id, updateCallback, method, errorCallback) {
  var pb = this;
  this.id = id;
  this.method = method || 'GET';
  this.updateCallback = updateCallback;
  this.errorCallback = errorCallback;

  // The WAI-ARIA setting aria-live="polite" will announce changes after users
  // have completed their current activity and not interrupt the screen reader.
  this.element = $('<div class="progress" aria-live="polite"></div>').attr('id', id);
  this.element.html('<div class="bar"><div class="filled"></div></div>' +
                    '<div class="percentage"></div>' +
                    '<div class="message">&nbsp;</div>');
};

/**
 * Set the percentage and status message for the progressbar.
 */
Drupal.progressBar.prototype.setProgress = function (percentage, message) {
  if (percentage >= 0 && percentage <= 100) {
    $('div.filled', this.element).css('width', percentage + '%');
    $('div.percentage', this.element).html(percentage + '%');
  }
  $('div.message', this.element).html(message);
  if (this.updateCallback) {
    this.updateCallback(percentage, message, this);
  }
};

/**
 * Start monitoring progress via Ajax.
 */
Drupal.progressBar.prototype.startMonitoring = function (uri, delay) {
  this.delay = delay;
  this.uri = uri;
  this.sendPing();
};

/**
 * Stop monitoring progress via Ajax.
 */
Drupal.progressBar.prototype.stopMonitoring = function () {
  clearTimeout(this.timer);
  // This allows monitoring to be stopped from within the callback.
  this.uri = null;
};

/**
 * Request progress data from server.
 */
Drupal.progressBar.prototype.sendPing = function () {
  if (this.timer) {
    clearTimeout(this.timer);
  }
  if (this.uri) {
    var pb = this;
    // When doing a post request, you need non-null data. Otherwise a
    // HTTP 411 or HTTP 406 (with Apache mod_security) error may result.
    $.ajax({
      type: this.method,
      url: this.uri,
      data: '',
      dataType: 'json',
      success: function (progress) {
        // Display errors.
        if (progress.status == 0) {
          pb.displayError(progress.data);
          return;
        }
        // Update display.
        pb.setProgress(progress.percentage, progress.message);
        // Schedule next timer.
        pb.timer = setTimeout(function () { pb.sendPing(); }, pb.delay);
      },
      error: function (xmlhttp) {
        pb.displayError(Drupal.ajaxError(xmlhttp, pb.uri));
      }
    });
  }
};

/**
 * Display errors on the page.
 */
Drupal.progressBar.prototype.displayError = function (string) {
  var error = $('<div class="messages error"></div>').html(string);
  $(this.element).before(error).hide();

  if (this.errorCallback) {
    this.errorCallback(this);
  }
};

})(jQuery);
;
/**
 * @file
 *
 * Implement a modal form.
 *
 * @see modal.inc for documentation.
 *
 * This javascript relies on the CTools ajax responder.
 */

(function ($) {
  // Make sure our objects are defined.
  Drupal.CTools = Drupal.CTools || {};
  Drupal.CTools.Modal = Drupal.CTools.Modal || {};

  /**
   * Display the modal
   *
   * @todo -- document the settings.
   */
  Drupal.CTools.Modal.show = function(choice) {
    var opts = {};

    if (choice && typeof choice == 'string' && Drupal.settings[choice]) {
      // This notation guarantees we are actually copying it.
      $.extend(true, opts, Drupal.settings[choice]);
    }
    else if (choice) {
      $.extend(true, opts, choice);
    }

    var defaults = {
      modalTheme: 'CToolsModalDialog',
      throbberTheme: 'CToolsModalThrobber',
      animation: 'show',
      animationSpeed: 'fast',
      modalSize: {
        type: 'scale',
        width: .8,
        height: .8,
        addWidth: 0,
        addHeight: 0,
        // How much to remove from the inner content to make space for the
        // theming.
        contentRight: 25,
        contentBottom: 45
      },
      modalOptions: {
        opacity: .55,
        background: '#fff'
      },
      modalClass: 'default'
    };

    var settings = {};
    $.extend(true, settings, defaults, Drupal.settings.CToolsModal, opts);

    if (Drupal.CTools.Modal.currentSettings && Drupal.CTools.Modal.currentSettings != settings) {
      Drupal.CTools.Modal.modal.remove();
      Drupal.CTools.Modal.modal = null;
    }

    Drupal.CTools.Modal.currentSettings = settings;

    var resize = function(e) {
      // When creating the modal, it actually exists only in a theoretical
      // place that is not in the DOM. But once the modal exists, it is in the
      // DOM so the context must be set appropriately.
      var context = e ? document : Drupal.CTools.Modal.modal;

      if (Drupal.CTools.Modal.currentSettings.modalSize.type == 'scale') {
        var width = $(window).width() * Drupal.CTools.Modal.currentSettings.modalSize.width;
        var height = $(window).height() * Drupal.CTools.Modal.currentSettings.modalSize.height;
      }
      else {
        var width = Drupal.CTools.Modal.currentSettings.modalSize.width;
        var height = Drupal.CTools.Modal.currentSettings.modalSize.height;
      }

      // Use the additionol pixels for creating the width and height.
      $('div.ctools-modal-content', context).css({
        'width': width + Drupal.CTools.Modal.currentSettings.modalSize.addWidth + 'px',
        'height': height + Drupal.CTools.Modal.currentSettings.modalSize.addHeight + 'px'
      });
      $('div.ctools-modal-content .modal-content', context).css({
        'width': (width - Drupal.CTools.Modal.currentSettings.modalSize.contentRight) + 'px',
        'height': (height - Drupal.CTools.Modal.currentSettings.modalSize.contentBottom) + 'px'
      });
    }

    if (!Drupal.CTools.Modal.modal) {
      Drupal.CTools.Modal.modal = $(Drupal.theme(settings.modalTheme));
      if (settings.modalSize.type == 'scale') {
        $(window).bind('resize', resize);
      }
    }

    resize();

    $('span.modal-title', Drupal.CTools.Modal.modal).html(Drupal.CTools.Modal.currentSettings.loadingText);
    Drupal.CTools.Modal.modalContent(Drupal.CTools.Modal.modal, settings.modalOptions, settings.animation, settings.animationSpeed, settings.modalClass);
    $('#modalContent .modal-content').html(Drupal.theme(settings.throbberTheme)).addClass('ctools-modal-loading');

    // Position autocomplete results based on the scroll position of the modal.
    $('#modalContent .modal-content').delegate('input.form-autocomplete', 'keyup', function() {
      $('#autocomplete').css('top', $(this).position().top + $(this).outerHeight() + $(this).offsetParent().filter('#modal-content').scrollTop());
    });
  };

  /**
   * Hide the modal
   */
  Drupal.CTools.Modal.dismiss = function() {
    if (Drupal.CTools.Modal.modal) {
      Drupal.CTools.Modal.unmodalContent(Drupal.CTools.Modal.modal);
    }
  };

  /**
   * Provide the HTML to create the modal dialog.
   */
  Drupal.theme.prototype.CToolsModalDialog = function () {
    var html = ''
    html += '<div id="ctools-modal">'
    html += '  <div class="ctools-modal-content">' // panels-modal-content
    html += '    <div class="modal-header">';
    html += '      <a class="close" href="#">';
    html +=          Drupal.CTools.Modal.currentSettings.closeText + Drupal.CTools.Modal.currentSettings.closeImage;
    html += '      </a>';
    html += '      <span id="modal-title" class="modal-title">&nbsp;</span>';
    html += '    </div>';
    html += '    <div id="modal-content" class="modal-content">';
    html += '    </div>';
    html += '  </div>';
    html += '</div>';

    return html;
  }

  /**
   * Provide the HTML to create the throbber.
   */
  Drupal.theme.prototype.CToolsModalThrobber = function () {
    var html = '';
    html += '<div id="modal-throbber">';
    html += '  <div class="modal-throbber-wrapper">';
    html +=      Drupal.CTools.Modal.currentSettings.throbber;
    html += '  </div>';
    html += '</div>';

    return html;
  };

  /**
   * Figure out what settings string to use to display a modal.
   */
  Drupal.CTools.Modal.getSettings = function (object) {
    var match = $(object).attr('class').match(/ctools-modal-(\S+)/);
    if (match) {
      return match[1];
    }
  }

  /**
   * Click function for modals that can be cached.
   */
  Drupal.CTools.Modal.clickAjaxCacheLink = function () {
    Drupal.CTools.Modal.show(Drupal.CTools.Modal.getSettings(this));
    return Drupal.CTools.AJAX.clickAJAXCacheLink.apply(this);
  };

  /**
   * Handler to prepare the modal for the response
   */
  Drupal.CTools.Modal.clickAjaxLink = function () {
    Drupal.CTools.Modal.show(Drupal.CTools.Modal.getSettings(this));
    return false;
  };

  /**
   * Submit responder to do an AJAX submit on all modal forms.
   */
  Drupal.CTools.Modal.submitAjaxForm = function(e) {
    var $form = $(this);
    var url = $form.attr('action');

    setTimeout(function() { Drupal.CTools.AJAX.ajaxSubmit($form, url); }, 1);
    return false;
  }

  /**
   * Bind links that will open modals to the appropriate function.
   */
  Drupal.behaviors.ZZCToolsModal = {
    attach: function(context) {
      // Bind links
      // Note that doing so in this order means that the two classes can be
      // used together safely.
      /*
       * @todo remimplement the warm caching feature
       $('a.ctools-use-modal-cache', context).once('ctools-use-modal', function() {
         $(this).click(Drupal.CTools.Modal.clickAjaxCacheLink);
         Drupal.CTools.AJAX.warmCache.apply(this);
       });
        */

      $('area.ctools-use-modal, a.ctools-use-modal', context).once('ctools-use-modal', function() {
        var $this = $(this);
        $this.click(Drupal.CTools.Modal.clickAjaxLink);
        // Create a drupal ajax object
        var element_settings = {};
        if ($this.attr('href')) {
          element_settings.url = $this.attr('href');
          element_settings.event = 'click';
          element_settings.progress = { type: 'throbber' };
        }
        var base = $this.attr('href');
        Drupal.ajax[base] = new Drupal.ajax(base, this, element_settings);
      });

      // Bind buttons
      $('input.ctools-use-modal, button.ctools-use-modal', context).once('ctools-use-modal', function() {
        var $this = $(this);
        $this.click(Drupal.CTools.Modal.clickAjaxLink);
        var button = this;
        var element_settings = {};

        // AJAX submits specified in this manner automatically submit to the
        // normal form action.
        element_settings.url = Drupal.CTools.Modal.findURL(this);
        if (element_settings.url == '') {
          element_settings.url = $(this).closest('form').attr('action');
        }
        element_settings.event = 'click';
        element_settings.setClick = true;

        var base = $this.attr('id');
        Drupal.ajax[base] = new Drupal.ajax(base, this, element_settings);

        // Make sure changes to settings are reflected in the URL.
        $('.' + $(button).attr('id') + '-url').change(function() {
          Drupal.ajax[base].options.url = Drupal.CTools.Modal.findURL(button);
        });
      });

      // Bind our custom event to the form submit
      $('#modal-content form', context).once('ctools-use-modal', function() {
        var $this = $(this);
        var element_settings = {};

        element_settings.url = $this.attr('action');
        element_settings.event = 'submit';
        element_settings.progress = { 'type': 'throbber' }
        var base = $this.attr('id');

        Drupal.ajax[base] = new Drupal.ajax(base, this, element_settings);
        Drupal.ajax[base].form = $this;

        $('input[type=submit], button', this).click(function(event) {
          Drupal.ajax[base].element = this;
          this.form.clk = this;
          // Stop autocomplete from submitting.
          if (Drupal.autocompleteSubmit && !Drupal.autocompleteSubmit()) {
            return false;
          }
          // An empty event means we were triggered via .click() and
          // in jquery 1.4 this won't trigger a submit.
          // We also have to check jQuery version to prevent
          // IE8 + jQuery 1.4.4 to break on other events
          // bound to the submit button.
          if (jQuery.fn.jquery.substr(0, 3) === '1.4' && typeof event.bubbles === "undefined") {
            $(this.form).trigger('submit');
            return false;
          }
        });
      });

      // Bind a click handler to allow elements with the 'ctools-close-modal'
      // class to close the modal.
      $('.ctools-close-modal', context).once('ctools-close-modal')
        .click(function() {
          Drupal.CTools.Modal.dismiss();
          return false;
        });
    }
  };

  // The following are implementations of AJAX responder commands.

  /**
   * AJAX responder command to place HTML within the modal.
   */
  Drupal.CTools.Modal.modal_display = function(ajax, response, status) {
    if ($('#modalContent').length == 0) {
      Drupal.CTools.Modal.show(Drupal.CTools.Modal.getSettings(ajax.element));
    }
    $('#modal-title').html(response.title);
    // Simulate an actual page load by scrolling to the top after adding the
    // content. This is helpful for allowing users to see error messages at the
    // top of a form, etc.
    $('#modal-content').html(response.output).scrollTop(0);

    // Attach behaviors within a modal dialog.
    var settings = response.settings || ajax.settings || Drupal.settings;
    Drupal.attachBehaviors($('#modalContent'), settings);

    if ($('#modal-content').hasClass('ctools-modal-loading')) {
      $('#modal-content').removeClass('ctools-modal-loading');
    }
    else {
      // If the modal was already shown, and we are simply replacing its
      // content, then focus on the first focusable element in the modal.
      // (When first showing the modal, focus will be placed on the close
      // button by the show() function called above.)
      $('#modal-content :focusable:first').focus();
    }
  }

  /**
   * AJAX responder command to dismiss the modal.
   */
  Drupal.CTools.Modal.modal_dismiss = function(command) {
    Drupal.CTools.Modal.dismiss();
    $('link.ctools-temporary-css').remove();
  }

  /**
   * Display loading
   */
  //Drupal.CTools.AJAX.commands.modal_loading = function(command) {
  Drupal.CTools.Modal.modal_loading = function(command) {
    Drupal.CTools.Modal.modal_display({
      output: Drupal.theme(Drupal.CTools.Modal.currentSettings.throbberTheme),
      title: Drupal.CTools.Modal.currentSettings.loadingText
    });
  }

  /**
   * Find a URL for an AJAX button.
   *
   * The URL for this gadget will be composed of the values of items by
   * taking the ID of this item and adding -url and looking for that
   * class. They need to be in the form in order since we will
   * concat them all together using '/'.
   */
  Drupal.CTools.Modal.findURL = function(item) {
    var url = '';
    var url_class = '.' + $(item).attr('id') + '-url';
    $(url_class).each(
      function() {
        var $this = $(this);
        if (url && $this.val()) {
          url += '/';
        }
        url += $this.val();
      });
    return url;
  };


  /**
   * modalContent
   * @param content string to display in the content box
   * @param css obj of css attributes
   * @param animation (fadeIn, slideDown, show)
   * @param speed (valid animation speeds slow, medium, fast or # in ms)
   * @param modalClass class added to div#modalContent
   */
  Drupal.CTools.Modal.modalContent = function(content, css, animation, speed, modalClass) {
    // If our animation isn't set, make it just show/pop
    if (!animation) {
      animation = 'show';
    }
    else {
      // If our animation isn't "fadeIn" or "slideDown" then it always is show
      if (animation != 'fadeIn' && animation != 'slideDown') {
        animation = 'show';
      }
    }

    if (!speed) {
      speed = 'fast';
    }

    // Build our base attributes and allow them to be overriden
    css = jQuery.extend({
      position: 'absolute',
      left: '0px',
      margin: '0px',
      background: '#000',
      opacity: '.55'
    }, css);

    // Add opacity handling for IE.
    css.filter = 'alpha(opacity=' + (100 * css.opacity) + ')';
    content.hide();

    // If we already have modalContent, remove it.
    if ($('#modalBackdrop').length) $('#modalBackdrop').remove();
    if ($('#modalContent').length) $('#modalContent').remove();

    // position code lifted from http://www.quirksmode.org/viewport/compatibility.html
    if (self.pageYOffset) { // all except Explorer
    var wt = self.pageYOffset;
    } else if (document.documentElement && document.documentElement.scrollTop) { // Explorer 6 Strict
      var wt = document.documentElement.scrollTop;
    } else if (document.body) { // all other Explorers
      var wt = document.body.scrollTop;
    }

    // Get our dimensions

    // Get the docHeight and (ugly hack) add 50 pixels to make sure we dont have a *visible* border below our div
    var docHeight = $(document).height() + 50;
    var docWidth = $(document).width();
    var winHeight = $(window).height();
    var winWidth = $(window).width();
    if( docHeight < winHeight ) docHeight = winHeight;

    // Create our divs
    $('body').append('<div id="modalBackdrop" class="backdrop-' + modalClass + '" style="z-index: 1000; display: none;"></div><div id="modalContent" class="modal-' + modalClass + '" style="z-index: 1001; position: absolute;">' + $(content).html() + '</div>');

    // Get a list of the tabbable elements in the modal content.
    var getTabbableElements = function () {
      var tabbableElements = $('#modalContent :tabbable'),
          radioButtons = tabbableElements.filter('input[type="radio"]');

      // The list of tabbable elements from jQuery is *almost* right. The
      // exception is with groups of radio buttons. The list from jQuery will
      // include all radio buttons, when in fact, only the selected radio button
      // is tabbable, and if no radio buttons in a group are selected, then only
      // the first is tabbable.
      if (radioButtons.length > 0) {
        // First, build up an index of which groups have an item selected or not.
        var anySelected = {};
        radioButtons.each(function () {
          var name = this.name;

          if (typeof anySelected[name] === 'undefined') {
            anySelected[name] = radioButtons.filter('input[name="' + name + '"]:checked').length !== 0;
          }
        });

        // Next filter out the radio buttons that aren't really tabbable.
        var found = {};
        tabbableElements = tabbableElements.filter(function () {
          var keep = true;

          if (this.type == 'radio') {
            if (anySelected[this.name]) {
              // Only keep the selected one.
              keep = this.checked;
            }
            else {
              // Only keep the first one.
              if (found[this.name]) {
                keep = false;
              }
              found[this.name] = true;
            }
          }

          return keep;
        });
      }

      return tabbableElements.get();
    };

    // Keyboard and focus event handler ensures only modal elements gain focus.
    modalEventHandler = function( event ) {
      target = null;
      if ( event ) { //Mozilla
        target = event.target;
      } else { //IE
        event = window.event;
        target = event.srcElement;
      }

      var parents = $(target).parents().get();
      for (var i = 0; i < parents.length; ++i) {
        var position = $(parents[i]).css('position');
        if (position == 'absolute' || position == 'fixed') {
          return true;
        }
      }

      if ($(target).is('#modalContent, body') || $(target).filter('*:visible').parents('#modalContent').length) {
        // Allow the event only if target is a visible child node
        // of #modalContent.
        return true;
      }
      else {
        getTabbableElements()[0].focus();
      }

      event.preventDefault();
    };
    $('body').bind( 'focus', modalEventHandler );
    $('body').bind( 'keypress', modalEventHandler );

    // Keypress handler Ensures you can only TAB to elements within the modal.
    // Based on the psuedo-code from WAI-ARIA 1.0 Authoring Practices section
    // 3.3.1 "Trapping Focus".
    modalTabTrapHandler = function (evt) {
      // We only care about the TAB key.
      if (evt.which != 9) {
        return true;
      }

      var tabbableElements = getTabbableElements(),
          firstTabbableElement = tabbableElements[0],
          lastTabbableElement = tabbableElements[tabbableElements.length - 1],
          singleTabbableElement = firstTabbableElement == lastTabbableElement,
          node = evt.target;

      // If this is the first element and the user wants to go backwards, then
      // jump to the last element.
      if (node == firstTabbableElement && evt.shiftKey) {
        if (!singleTabbableElement) {
          lastTabbableElement.focus();
        }
        return false;
      }
      // If this is the last element and the user wants to go forwards, then
      // jump to the first element.
      else if (node == lastTabbableElement && !evt.shiftKey) {
        if (!singleTabbableElement) {
          firstTabbableElement.focus();
        }
        return false;
      }
      // If this element isn't in the dialog at all, then jump to the first
      // or last element to get the user into the game.
      else if ($.inArray(node, tabbableElements) == -1) {
        // Make sure the node isn't in another modal (ie. WYSIWYG modal).
        var parents = $(node).parents().get();
        for (var i = 0; i < parents.length; ++i) {
          var position = $(parents[i]).css('position');
          if (position == 'absolute' || position == 'fixed') {
            return true;
          }
        }

        if (evt.shiftKey) {
          lastTabbableElement.focus();
        }
        else {
          firstTabbableElement.focus();
        }
      }
    };
    $('body').bind('keydown', modalTabTrapHandler);

    // Create our content div, get the dimensions, and hide it
    var modalContent = $('#modalContent').css('top','-1000px');
    var $modalHeader = modalContent.find('.modal-header');
    var mdcTop = wt + ( winHeight / 2 ) - (  modalContent.outerHeight() / 2);
    var mdcLeft = ( winWidth / 2 ) - ( modalContent.outerWidth() / 2);
    $('#modalBackdrop').css(css).css('top', 0).css('height', docHeight + 'px').css('width', docWidth + 'px').show();
    modalContent.css({top: mdcTop + 'px', left: mdcLeft + 'px'}).hide()[animation](speed);

    // Bind a click for closing the modalContent
    modalContentClose = function(){close(); return false;};
    $('.close', $modalHeader).bind('click', modalContentClose);

    // Bind a keypress on escape for closing the modalContent
    modalEventEscapeCloseHandler = function(event) {
      if (event.keyCode == 27) {
        close();
        return false;
      }
    };

    $(document).bind('keydown', modalEventEscapeCloseHandler);

    // Per WAI-ARIA 1.0 Authoring Practices, initial focus should be on the
    // close button, but we should save the original focus to restore it after
    // the dialog is closed.
    var oldFocus = document.activeElement;
    $('.close', $modalHeader).focus();

    // Close the open modal content and backdrop
    function close() {
      // Unbind the events
      $(window).unbind('resize',  modalContentResize);
      $('body').unbind( 'focus', modalEventHandler);
      $('body').unbind( 'keypress', modalEventHandler );
      $('body').unbind( 'keydown', modalTabTrapHandler );
      $('.close', $modalHeader).unbind('click', modalContentClose);
      $('body').unbind('keypress', modalEventEscapeCloseHandler);
      $(document).trigger('CToolsDetachBehaviors', $('#modalContent'));

      // Set our animation parameters and use them
      if ( animation == 'fadeIn' ) animation = 'fadeOut';
      if ( animation == 'slideDown' ) animation = 'slideUp';
      if ( animation == 'show' ) animation = 'hide';

      // Close the content
      modalContent.hide()[animation](speed);

      // Remove the content
      $('#modalContent').remove();
      $('#modalBackdrop').remove();

      // Restore focus to where it was before opening the dialog
      $(oldFocus).focus();
    };

    // Move and resize the modalBackdrop and modalContent on window resize.
    modalContentResize = function(){

      // Reset the backdrop height/width to get accurate document size.
      $('#modalBackdrop').css('height', '').css('width', '');

      // Position code lifted from:
      // http://www.quirksmode.org/viewport/compatibility.html
      if (self.pageYOffset) { // all except Explorer
      var wt = self.pageYOffset;
      } else if (document.documentElement && document.documentElement.scrollTop) { // Explorer 6 Strict
        var wt = document.documentElement.scrollTop;
      } else if (document.body) { // all other Explorers
        var wt = document.body.scrollTop;
      }

      // Get our heights
      var docHeight = $(document).height();
      var docWidth = $(document).width();
      var winHeight = $(window).height();
      var winWidth = $(window).width();
      if( docHeight < winHeight ) docHeight = winHeight;

      // Get where we should move content to
      var modalContent = $('#modalContent');
      var mdcTop = wt + ( winHeight / 2 ) - ( modalContent.outerHeight() / 2);
      var mdcLeft = ( winWidth / 2 ) - ( modalContent.outerWidth() / 2);

      // Apply the changes
      $('#modalBackdrop').css('height', docHeight + 'px').css('width', docWidth + 'px').show();
      modalContent.css('top', mdcTop + 'px').css('left', mdcLeft + 'px').show();
    };
    $(window).bind('resize', modalContentResize);
  };

  /**
   * unmodalContent
   * @param content (The jQuery object to remove)
   * @param animation (fadeOut, slideUp, show)
   * @param speed (valid animation speeds slow, medium, fast or # in ms)
   */
  Drupal.CTools.Modal.unmodalContent = function(content, animation, speed)
  {
    // If our animation isn't set, make it just show/pop
    if (!animation) { var animation = 'show'; } else {
      // If our animation isn't "fade" then it always is show
      if (( animation != 'fadeOut' ) && ( animation != 'slideUp')) animation = 'show';
    }
    // Set a speed if we dont have one
    if ( !speed ) var speed = 'fast';

    // Unbind the events we bound
    $(window).unbind('resize', modalContentResize);
    $('body').unbind('focus', modalEventHandler);
    $('body').unbind('keypress', modalEventHandler);
    $('body').unbind( 'keydown', modalTabTrapHandler );
    var $modalContent = $('#modalContent');
    var $modalHeader = $modalContent.find('.modal-header');
    $('.close', $modalHeader).unbind('click', modalContentClose);
    $('body').unbind('keypress', modalEventEscapeCloseHandler);
    $(document).trigger('CToolsDetachBehaviors', $modalContent);

    // jQuery magic loop through the instances and run the animations or removal.
    content.each(function(){
      if ( animation == 'fade' ) {
        $('#modalContent').fadeOut(speed, function() {
          $('#modalBackdrop').fadeOut(speed, function() {
            $(this).remove();
          });
          $(this).remove();
        });
      } else {
        if ( animation == 'slide' ) {
          $('#modalContent').slideUp(speed,function() {
            $('#modalBackdrop').slideUp(speed, function() {
              $(this).remove();
            });
            $(this).remove();
          });
        } else {
          $('#modalContent').remove();
          $('#modalBackdrop').remove();
        }
      }
    });
  };

$(function() {
  Drupal.ajax.prototype.commands.modal_display = Drupal.CTools.Modal.modal_display;
  Drupal.ajax.prototype.commands.modal_dismiss = Drupal.CTools.Modal.modal_dismiss;
});

})(jQuery);
;
/**
 * @file
 *
 * CTools flexible AJAX responder object.
 */

(function ($) {
  Drupal.CTools = Drupal.CTools || {};
  Drupal.CTools.AJAX = Drupal.CTools.AJAX || {};
  /**
   * Grab the response from the server and store it.
   *
   * @todo restore the warm cache functionality
   */
  Drupal.CTools.AJAX.warmCache = function () {
    // Store this expression for a minor speed improvement.
    $this = $(this);
    var old_url = $this.attr('href');
    // If we are currently fetching, or if we have fetched this already which is
    // ideal for things like pagers, where the previous page might already have
    // been seen in the cache.
    if ($this.hasClass('ctools-fetching') || Drupal.CTools.AJAX.commandCache[old_url]) {
      return false;
    }

    // Grab all the links that match this url and add the fetching class.
    // This allows the caching system to grab each url once and only once
    // instead of grabbing the url once per <a>.
    var $objects = $('a[href="' + old_url + '"]')
    $objects.addClass('ctools-fetching');
    try {
      url = old_url.replace(/\/nojs(\/|$)/g, '/ajax$1');
      $.ajax({
        type: "POST",
        url: url,
        data: { 'js': 1, 'ctools_ajax': 1},
        global: true,
        success: function (data) {
          Drupal.CTools.AJAX.commandCache[old_url] = data;
          $objects.addClass('ctools-cache-warmed').trigger('ctools-cache-warm', [data]);
        },
        complete: function() {
          $objects.removeClass('ctools-fetching');
        },
        dataType: 'json'
      });
    }
    catch (err) {
      $objects.removeClass('ctools-fetching');
      return false;
    }

    return false;
  };

  /**
   * Cachable click handler to fetch the commands out of the cache or from url.
   */
  Drupal.CTools.AJAX.clickAJAXCacheLink = function () {
    $this = $(this);
    if ($this.hasClass('ctools-fetching')) {
      $this.bind('ctools-cache-warm', function (event, data) {
        Drupal.CTools.AJAX.respond(data);
      });
      return false;
    }
    else {
      if ($this.hasClass('ctools-cache-warmed') && Drupal.CTools.AJAX.commandCache[$this.attr('href')]) {
        Drupal.CTools.AJAX.respond(Drupal.CTools.AJAX.commandCache[$this.attr('href')]);
        return false;
      }
      else {
        return Drupal.CTools.AJAX.clickAJAXLink.apply(this);
      }
    }
  };

  /**
   * Find a URL for an AJAX button.
   *
   * The URL for this gadget will be composed of the values of items by
   * taking the ID of this item and adding -url and looking for that
   * class. They need to be in the form in order since we will
   * concat them all together using '/'.
   */
  Drupal.CTools.AJAX.findURL = function(item) {
    var url = '';
    var url_class = '.' + $(item).attr('id') + '-url';
    $(url_class).each(
      function() {
        var $this = $(this);
        if (url && $this.val()) {
          url += '/';
        }
        url += $this.val();
      });
    return url;
  };

  // Hide these in a ready to ensure that Drupal.ajax is set up first.
  $(function() {
    Drupal.ajax.prototype.commands.attr = function(ajax, data, status) {
      $(data.selector).attr(data.name, data.value);
    };


    Drupal.ajax.prototype.commands.redirect = function(ajax, data, status) {
      if (data.delay > 0) {
        setTimeout(function () {
          location.href = data.url;
        }, data.delay);
      }
      else {
        location.href = data.url;
      }
    };

    Drupal.ajax.prototype.commands.reload = function(ajax, data, status) {
      location.reload();
    };

    Drupal.ajax.prototype.commands.submit = function(ajax, data, status) {
      $(data.selector).submit();
    }
  });
})(jQuery);
;
var contentoptimizer_contentanalysis_data = function(aid) {		
  data = new Array();	
  data['keyword'] = document.getElementById('edit-seo-keyword').value;	
  return data;
};

var kwresearch = kwresearch || {};

(function ($, $$) {
	$.extend($$, {
		kwresearch_keyword_data: {},
		
		init: function() {
			$$.kwresearch_init();
		},
		
		kwresearch_init: function () {
		  var report_vocabs = Drupal.settings.kwresearch.tax_report_vocabs;
		  for(var vid in report_vocabs) {
			if (report_vocabs[vid] > 0 && ($('.kwresearch-refresh-link-' + vid).length == 0)) {
		      h = '<a href="#" class="kwresearch.kwresearch-refresh-link-' + vid + '" onclick="kwresearch.kwresearch_refresh_tax_report(\'' + vid + '\'); return false;" title="refresh report">';
		      h += '<img src="' + Drupal.settings.kwresearch.path_to_module + '/icons/refresh.png" alt="refresh report" />';
		      h += '</a>';
		      $('.kwresearch-tax-report-' + vid + ' label').append(h);
			}
		  } 
		  $$.kwresearch_process_keywords();
		},
		
		kwresearch_get_keyword_list: function(type) {
		  var value = '';
		  var keywords = new Array();
		  
		  if (type == 'vocab') {
		    if (Drupal.settings.kwresearch.keyword_tag_vocabulary) {    
		      if ($('#edit-taxonomy-tags-' + Drupal.settings.kwresearch.keyword_tag_vocabulary).val() != null) {
		        value = $('#edit-taxonomy-tags-' + Drupal.settings.kwresearch.keyword_tag_vocabulary).val();
		      } 
		    }    
		  }
		  else if (type == 'mlt') {
		    if ($('#edit-morelikethis-terms').val() != null) {
		      value = $('#edit-morelikethis-terms').val();  
		    }
		  }
		  else if (type == 'meta_keywords') {
		    if ($('#edit-nodewords-keywords-value').val() != null) {
		      value = $('#edit-nodewords-keywords-value').val();
		    }
		  }
		  
		  keywords = value.split(',');  
		  for(var i in keywords) {
		    keywords[i] = jQuery.trim(keywords[i].toLowerCase());
		  }
		  return keywords;
		},
		
		// Implementation of hook_contentanalysis_analysis_success
		kwresearch_contentanalysis_analysis_success: function(aid, data) {	
			$$.kwresearch_init();	
		},

		kwresearch_in_array: function(needle, haystack) {
			for(var i = 0; i < haystack.length; i++) {
				if (haystack[i] == needle) {
					return true;
				}
			}
			return false;
		},

		kwresearch_process_keywords: function() {
		//alert('hi');
		  $('.kwresearch_keyword:not(.processed)').each( function(index) {
		    keyword = $(this).text().toLowerCase();
		    str = $$.kwresearch_get_buttons(keyword);
		    
		    $(this).addClass('processed');
		    $(this).append(str);
		    $('.kwresearch_actions').hide();
		    $(this).mouseover( function() {
		      $(this).addClass('active');
		      var tools = $(this).find('.kwresearch_actions');
		      var pos = $(this).position(); 
		      var left = pos.left; 
		      var top = pos.top;
		      var topOffset = $(this).height();
		      var xTip = (left-0)+"px";  
		      //var yTip = (0-topOffset+top)+"px";  
		      var yTip = (0+top)+"px";  
		      tools.css({'top' : yTip, 'left' : xTip});  
		      tools.show();
		      
		    });
		    $(this).mouseout( function() {
		      var tools = $(this).find('.kwresearch_actions');
		      $(this).removeClass('active');
		      tools.hide();
		    });
		  });
		},

		kwresearch_get_buttons: function(keyword) {
		    str = '<div class="kwresearch_actions">';
		    title = Drupal.t('Keyword report');
            if (Drupal.settings.kwresearch.permissions.query_keyword_stats) {
                str += '<a href="#" onclick="kwresearch.kwresearch_launch_report(\'' + keyword + '\'); return false;" title="' + title + '" class="kwresearch-tool-button">';
                str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/report.png" title="' + title + '" />';
                str += '</a>';
            }
            if (Drupal.settings.kwresearch.permissions.admin_site_keywords) {
                str += $$.kwresearch_get_toggle_button(keyword, 'sitekw');
                str += $$.kwresearch_get_toggle_button(keyword, 'siteops');
            }
            if (Drupal.settings.kwresearch.permissions.admin_page_keywords) {
                str += $$.kwresearch_get_toggle_button(keyword, 'pagekw');
            }
		    str += $$.kwresearch_get_toggle_button(keyword, 'vocab');
		    str += $$.kwresearch_get_toggle_button(keyword, 'mlt');
		    str += $$.kwresearch_get_toggle_button(keyword, 'meta_keywords');

		    str += '</div>';
		    return str;
		},

		kwresearch_get_toggle_button: function(keyword, type) {
		  var str = '';
		  var keyword_list = $$.kwresearch_get_keyword_list(type);
		  if (type == 'sitekw') {  
		    if (Drupal.settings.kwresearch.enable_site_keyword_tool) { // TODO add admin permission logic
		      keywordns = keyword.replace(/ /g,'-');
		      add = 1;
		      img = 'add';
		      title = Drupal.t('Add keyword to targeted site keyword list');
		      var d = Drupal.settings.kwresearch.site_keywords_data;
		      var activei = -1;
		      if ((d[keyword] != null) && (d[keyword]['priority'] >= 0)) {
		        add = 0;
		        img = 'delete'
		        title = Drupal.t('Remove keyword from targeted site keyword list');
		        activei = d[keyword]['priority'];
		      }
		      str += '<div onmouseover="kwresearch.kwresearch_display_tool_site_keyword_menu(this, 1);" onmouseout="kwresearch.kwresearch_display_tool_site_keyword_menu(this, 0);" class="kwresearch-tool-group kwresearch-tool-button kwresearch-tool-button-site-keyword-' + keywordns + '">'
		      str += '<a href="#" onclick="kwresearch.kwresearch_toggle_sitekw_keyword(\'' + keyword + '\', ' + add + ', \'' + keywordns + '\'); return false;" title="' + title + '" >';
		      str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/site_keyword_' + img + '.png" title="' + title + '" />';
		      str += '</a>';      

		      str += '<ul class="kwresearch-tool-menu kwresearch-tool-menu-site-priority-' + keyword + '" style="display: none; left: 0px; top: 18px;">';
		      op = Drupal.settings.kwresearch.site_priority_options;
		      for ( var i in op ) {
		        active = '';
		        if (activei == i) {
		          active = 'active';
		        }
		        str += '<li class="' + active + '"><a href="#" onclick="kwresearch.kwresearch_toggle_sitekw_keyword(\'' + keyword + '\', ' + add + ', \'' + keywordns + '\', ' + i + '); return false;">' + op[i] + '</a></li>';
		      }
		      str += '</ul>';  
		      str += '</div>';      
		    }
		  }
		  if (type == 'siteops') {
			var d = Drupal.settings.kwresearch.site_keywords_data;
			if ((Drupal.settings.kwresearch.form != null) && (Drupal.settings.kwresearch.form.substr(0, 5) == 'admin')) {
				var link = Drupal.settings.kwresearch.keyword_edit_path + d[keyword]['kid'];
				if (Drupal.settings.kwresearch.return_destination) {
			  		link += '?destination=' + Drupal.settings.kwresearch.return_destination;
			  	}
			  	var title = Drupal.t('Edit keyword');
			    str += '<a href="' + link + '" onclick="kwresearch.kwresearch_edit_keyword(' + d[keyword]['kid'] + '); return false;" title="' + title + '" class="kwresearch-tool-button">';
			    str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/keyword_edit.png" title="' + title + '" />';
			    str += '</a>';   	  
			}
		    if ((Drupal.settings.kwresearch.form != null) && (Drupal.settings.kwresearch.form == 'admin_keyword_list') && !(d[keyword]['page_count'] > 0)) {
		    	var title = Drupal.t('Delete keyword');
			    str += '<a href="#" onclick="kwresearch.kwresearch_delete_keyword(\'' + escape(keyword) + '\', ' + d[keyword]['kid'] + '); return false;" title="' + title + '" class="kwresearch-tool-button">';
			    str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/keyword_delete.png" title="' + title + '" />';
			    str += '</a>';   	  
		    }	  
		  }
		  if (type == 'pagekw') {  
		    if (Drupal.settings.kwresearch.enable_page_keyword_tool) { // TODO add admin permission logic
		      add = 1;
		      img = 'add';
		      title = Drupal.t('Add keyword to page keyword list');
		      var d = Drupal.settings.kwresearch.page_keywords_data;
		      var activei = 0;
		      if ((d[keyword] != null) && (d[keyword]['priority'] > 0)) {
		        add = 0;
		        img = 'delete'
		        title = Drupal.t('Remove keyword from page keyword list');
		        activei = d[keyword]['priority'];
		      }
		      /*
		      str += '<a href="#" onclick="kwresearch_toggle_pagekw_keyword(\'' + keyword + '\', ' + add + ', this); return false;" title="' + title + '" class="kwresearch-tool-button">';
		      str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/page_keyword_' + img + '.png" title="' + title + '" />';
		      str += '</a>';
		      */      
		      str += '<div onmouseover="kwresearch.kwresearch_display_tool_page_keyword_menu(this, 1);" onmouseout="kwresearch.kwresearch_display_tool_page_keyword_menu(this, 0);" class="kwresearch-tool-group kwresearch-tool-button kwresearch-tool-button-page-keyword-' + keywordns + '">'
		      str += '<a href="#" onclick="kwresearch.kwresearch_toggle_pagekw_keyword(\'' + keyword + '\', ' + add + ', \'' + keywordns + '\'); return false;" title="' + title + '" >';
		      str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/page_keyword_' + img + '.png" title="' + title + '" />';
		      str += '</a>';      

		      str += '<ul class="kwresearch-tool-menu kwresearch-tool-menu-site-priority-' + keyword + '" style="display: none; left: 18px; top: 18px;">';
		      op = Drupal.settings.kwresearch.page_priority_options;
		      for ( var i in op ) {
		        active = '';
		        if (activei == i) {
		          active = 'active';
		        }
		        str += '<li class="' + active + '"><a href="#" onclick="kwresearch.kwresearch_toggle_pagekw_keyword(\'' + keyword + '\', ' + add + ', \'' + keywordns + '\', ' + i + '); return false;">' + op[i] + '</a></li>';
		      }
		      str += '</ul>';    
		      str += '</div>';      
		      
		    }
		  }
		  else if (type == 'vocab') {
		    if (Drupal.settings.kwresearch.keyword_tag_vocabulary 
		      && ($('#edit-taxonomy-tags-' + Drupal.settings.kwresearch.keyword_tag_vocabulary).size() > 0)) {
		      add = 1;
		      img = 'add';
		      title = Drupal.t('Add keyword to keyword vocabulary');
		      
		      if ($$.kwresearch_in_array(keyword, keyword_list)) {
		        add = 0;
		        img = 'delete'
		        title = Drupal.t('Remove keyword from keyword vocabulary');
		      }
		      keyword
		      str += '<a href="#" onclick="kwresearch.kwresearch_toggle_vocab_keyword(\'' + keyword + '\', ' + add + ', this); return false;" title="' + title + '" class="kwresearch-tool-button">';
		      str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/vocab_' + img + '.png" title="' + title + '" />';
		      str += '</a>';       
		    }
		  }
		  else if (type == 'mlt') {  
		    if ($('#edit-morelikethis-terms').size() > 0) {
		      add = 1;
		      img = 'add';
		      title = Drupal.t('Add keyword to More Like This');
		      if ($$.kwresearch_in_array(keyword, keyword_list)) {
		        add = 0;
		        img = 'delete'
		        title = Drupal.t('Remove keyword from More Like This');
		      }
		      str += '<a href="#" onclick="kwresearch.kwresearch_toggle_mlt_keyword(\'' + keyword + '\', ' + add + ', this); return false;" title="' + title + '" class="kwresearch-tool-button">';
		      str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/mlt_' + img + '.png" title="' + title + '" />';
		      str += '</a>';
		    }
		  }
		  else if (type == 'meta_keywords') {  
		    if ($('#edit-nodewords-keywords-value').size() > 0) {
		      add = 1;
		      img = 'add';
		      title = Drupal.t('Add keyword to meta keywords');
		      if ($$.kwresearch_in_array(keyword, keyword_list)) {
		        add = 0;
		        img = 'delete'
		        title = Drupal.t('Remove keyword to meta keywords');
		      }
		      str += '<a href="#" onclick="kwresearch.kwresearch_toggle_meta_keyword(\'' + keyword + '\', ' + add + ', this); return false;" title="' + title + '" class="kwresearch-tool-button">';
		      str += '<img src="' + Drupal.settings.kwresearch.module_path + '/icons/metakeywords_' + img + '.png" title="' + title + '" />';
		      str += '</a>';
		    }
		  }
		  return str
		},

		kwresearch_display_tool_site_keyword_menu: function(theDiv, state) {
		  if (state == 1) {
		    $(theDiv).children('ul').show();
		  }
		  else {
		    $(theDiv).children('ul').hide();
		  }
		},

		kwresearch_display_tool_page_keyword_menu: function(theDiv, state) {
		  if (state == 1) {
		    $(theDiv).children('ul').show();
		  }
		  else {
		    $(theDiv).children('ul').hide();
		  }
		},

		kwresearch_launch_report: function(keyword) {
		  if (Drupal.settings.kwresearch.form.substr(0,5) == 'admin') {
		    window.location = Drupal.settings.kwresearch.analyze_path + keyword;
		    return false;
		  }
		  $('#edit-kwresearch-keyword').val(keyword);
		  contentanalysis.contentanalysis_show_analyzer_tab(document.getElementById('contentanalysis-analyzer-tab-kwresearch'));
		  $$.kwresearch_analyze();
		  return false;
		},

		kwresearch_toggle_sitekw_keyword: function(keyword, add, keywordns, priority) {
		  var data = { 
		    'kwresearch_keyword': keyword,
		    'priority': -1,
		    'form': Drupal.settings.kwresearch.form,
			'token': Drupal.settings.kwresearch.post_token
		  };
		  if (priority != null) {
		    data.priority = priority;
		    $('.kwresearch_actions').hide();
		  }
		  else if (add == 1) {
		    data.priority = 50;
		  }  

		  $.ajax({
		    type: 'POST',
		    url: Drupal.settings.kwresearch.toggle_site_keyword_callback,
		    data: data,
		    dataType: 'json',
		    success: function(data, textStatus) {
			  var keyword = String(data.data['keyword']).toString();
		      if (Drupal.settings.kwresearch.site_keywords_data[keyword] == null) {
		        Drupal.settings.kwresearch.site_keywords_data[keyword] = {
		          'priority': data.data['priority']
		        }
		      }
		      else {
		        Drupal.settings.kwresearch.site_keywords_data[keyword]['priority'] = data.data['priority'];
		      }
		//alert(Drupal.settings.kwresearch.site_keywords_data[data.data['keyword']]['priority']);
		      $('.kwresearch-tool-button-site-keyword-' + keywordns).replaceWith($$.kwresearch_get_toggle_button(keyword, 'sitekw'));
		      //$(theLink).replaceWith(kwresearch_get_toggle_button(keyword, 'sitekw'));
		      if (Drupal.settings.kwresearch.form == 'admin_keyword_list') {
		    	$('#kid-' + data.data['kid']).hide();
		    	$('#kid-' + data.data['kid'] + ' .site_priority').replaceWith('<td class="site_priority">' + data.data['priority_out'] + "</td>");
		        $('#kid-' + data.data['kid'] + ' .value').replaceWith('<td class="value">' + data.data['value_out'] + "</td>");
		        $('#kid-' + data.data['kid'] + ' .user').replaceWith('<td class="user">' + data.data['user_out'] + "</td>");        
		        $('#kid-' + data.data['kid']).fadeIn(100);
		      }
		      if (Drupal.settings.kwresearch.form == 'admin_keyword_stats') {
		      	$('#kid-' + data.data['kid']).hide();
		      	$('#kid-' + data.data['kid'] + ' .site_priority').replaceWith('<td class="site_priority">' + data.data['priority_out'] + "</td>");
		        $('#kid-' + data.data['kid'] + ' .value').replaceWith('<td class="value">' + data.data['value_out'] + "</td>");
		        $('#kid-' + data.data['kid'] + ' .user').replaceWith('<td class="user">' + data.data['user_out'] + "</td>");
		        $('#kid-' + data.data['kid']).fadeIn(100);
		      }
		      if (Drupal.settings.kwresearch.form == 'node_edit') {
			    	$('#kid-' + data.data['kid']).hide();
			    	$('#kid-' + data.data['kid'] + ' .site_priority').replaceWith('<td class="site_priority">' + data.data['priority_out'] + "</td>");
			        $('#kid-' + data.data['kid'] + ' .value').replaceWith('<td class="value">' + data.data['value_out'] + "</td>");
			        $('#kid-' + data.data['kid'] + ' .user').replaceWith('<td class="user">' + data.data['user_out'] + "</td>");        
			        $('#kid-' + data.data['kid']).fadeIn(100);
			      }
		    },
		    error: function(XMLHttpRequest, textStatus, errorThrown) {

		    }
		  });

		  return false;  
		},

		kwresearch_edit_keyword: function(kid) {
			var loc = Drupal.settings.kwresearch.keyword_edit_path + kid;
			if (Drupal.settings.kwresearch.return_destination) {
			  loc += '?destination=' + Drupal.settings.kwresearch.return_destination;
			}
			window.location	= loc;
			return false;
		},

		kwresearch_delete_keyword: function(keyword, kid) {
		  keyword = unescape(keyword);
		  if (Drupal.settings.kwresearch.site_keywords_data[keyword]['priority'] > 0) {
			if (!confirm(Drupal.t('This keyword has a site priority. Are you sure you want to delete it?'))) {
				return false;
			}
		  }
		  var data = { 
		    'kwresearch_keyword': keyword,
		    'kid': kid,
		    'form': Drupal.settings.kwresearch.form,
			'token' : Drupal.settings.kwresearch.post_token
		  };

		  $.ajax({
		    type: 'POST',
		    url: Drupal.settings.kwresearch.delete_site_keyword_callback,
		    data: data,
		    dataType: 'json',
		    success: function(data, textStatus) {
			  	if (data.data['deleted']) {
		// TODO this does not work with multiple deletes
		    	  $('#kid-' + data.data['kid']).fadeOut(100);
		    	  $('#kid-' + data.data['kid']).remove();
			  	}
		    },
		    error: function(XMLHttpRequest, textStatus, errorThrown) {

		    }
		  });

		  return false;  
		},

		kwresearch_toggle_pagekw_keyword: function(keyword, add, keywordns, priority) {
		  
		  // update sync vocabulary
		  v = $('#edit-' + Drupal.settings.kwresearch.sync_vocab_field).val();
		  if (add) {    
		    nv = v + (v ? ', ' : '') + keyword;    
		  }
		  else {
		    nv = $$.kwresearch_remove_phrase_from_list(keyword, v);
		  }
		  $('#edit-' + Drupal.settings.kwresearch.sync_vocab_field).val(nv);

          // check seo keyword field. If empty, add keyword to field
          if ($('#edit-seo-keyword').length) {
            v = $('#edit-seo-keyword').val();
            if (!v) {
              $('#edit-seo-keyword').val(keyword);
            }
          }
		  
		  // do ajax call to store in database
		  var data = { 
		    'kwresearch_keyword': keyword,
		    'priority': 0,
		    'nid': Drupal.settings.contentanalysis.nid,
			'token' : Drupal.settings.kwresearch.post_token
		  };
		  if (priority != null) {
		    data.priority = priority;
		    $('.kwresearch_actions').hide();
		  }
		  else if (add) {    
		    data.priority = 50;  
		  } 

		  $.ajax({
		    type: 'POST',
		    url: Drupal.settings.kwresearch.toggle_page_keyword_callback,
		    data: data,
		    dataType: 'json',
		    success: function(data, textStatus) {
		      if (Drupal.settings.kwresearch.page_keywords_data[data.data['keyword']] == null) {
		        Drupal.settings.kwresearch.page_keywords_data[data.data['keyword']] = {
		          'priority': data.data['priority']
		        }
		      }
		      else {
		        Drupal.settings.kwresearch.page_keywords_data[data.data['keyword']]['priority'] = data.data['priority'];
		      }
		      //$(theLink).replaceWith(kwresearch_get_toggle_button(keyword, 'pagekw'));
		      $('.kwresearch-tool-button-page-keyword-' + keywordns).replaceWith($$.kwresearch_get_toggle_button(data.data['keyword'], 'pagekw'));

		    },
		    error: function(XMLHttpRequest, textStatus, errorThrown) {

		    }
		  });

		  return false;  
		},

		kwresearch_toggle_vocab_keyword: function(keyword, add, theLink) {
		  v = $('#edit-' + Drupal.settings.kwresearch.sync_vocab_field).val();
		  if (add) {    
		    nv = v + (v ? ', ' : '') + keyword;    
		  }
		  else {
		    nv = $$.kwresearch_remove_phrase_from_list(keyword, v);
		  }
		  $('#edit-' + Drupal.settings.kwresearch.sync_vocab_field).val(nv);
		  $(theLink).replaceWith($$.kwresearch_get_toggle_button(keyword, 'vocab'));
		  return false;
		},

		kwresearch_toggle_mlt_keyword: function(keyword, add, theLink) {
		  v = $('#edit-morelikethis-terms').val();
		  if (add) {    
		    nv = v + (v ? ', ' : '') + keyword;    
		  }
		  else {
		    nv = $$.kwresearch_remove_phrase_from_list(keyword, v);
		  }
		  $('#edit-morelikethis-terms').val(nv);
		  $(theLink).replaceWith($$.kwresearch_get_toggle_button(keyword, 'mlt'));
		  return false;
		},

		kwresearch_toggle_meta_keyword: function(keyword, add, theLink) {
		  v = $('#edit-metatags-keywords-value').val();
		  if (add) {    
		    nv = v + (v ? ', ' : '') + keyword;    
		  }
		  else {
		    nv = $$.kwresearch_remove_phrase_from_list(keyword, v);
		  }
		  $('#edit-metatags-keywords-value').val(nv);
		  $(theLink).replaceWith($$.kwresearch_get_toggle_button(keyword, 'meta_keywords'));
		  return false;
		},

		kwresearch_remove_phrase_from_list: function(keyword, list) {
		  kws0 = list.split(',');  
		  kws1 = new Array();
		  j = 0;
		  for(var i in kws0) {    
		    k = jQuery.trim(kws0[i].toLowerCase());
		    if (k != keyword) {
		      kws1[j] = k;
		      j++;
		    }    
		  }  
		  return kws1.join(', ');
		},

		kwresearch_analyze: function() {
		  var data = {
		    'kwresearch_keyword': '',
		    'kwresearch_include_misspellings': 0,
		    'kwresearch_include_plurals': 0,
		    'kwresearch_adult_filter':$('#edit-kwresearch-adult-filter:selected').val(),
		    'kwresearch_nid': -1,
			'kwresearch_token' : Drupal.settings.kwresearch.post_token
		  };
		  data.kwresearch_keyword = $('#edit-kwresearch-keyword').val();
		  if ($('#edit-kwresearch-include-misspellings:checked').val() != null) {
		    data.kwresearch_include_misspellings = 1;
		  }
		  if ($('#edit-kwresearch-include-plurals:checked').val() != null) {
		    data.kwresearch_include_plurals = 1;
		  }
		  if (Drupal.settings.contentanalysis.nid > 0) {
		    data.kwresearch_nid = Drupal.settings.contentanalysis.nid;
		  }
		  
		  $('.kwresearch-result-block').hide();
		  var id = 'kwresearch-result-block-' + data.kwresearch_keyword.replace(/ /g, '-').toLowerCase();
		  var existing = $('#' + id);
		  if (existing.size() > 0) {
		    $(existing).show();
		  } else {
		    $('#kwresearch-submit-button').after('<div class="ahah-progress ahah-progress-throbber"><div class="throbber">&nbsp;</div><div class="message">' + Drupal.t('Analyzing...') + '</div></div>');
		    $('#kwresearch-submit-button').hide();  
		    $.ajax({
		      type: 'POST',
		      url: Drupal.settings.kwresearch.analyze_callback,
		      data: data,
		      dataType: 'json',
		      success: function(data, textStatus) {
		        $('#kwresearch-report').append(data.report['output']);
		        $$.kwresearch_init();
		        $('.ahah-progress-throbber').remove();
		        $('#kwresearch-submit-button').show();
		        //$$.kwresearch_keyword_data = $$.kwresearch_keyword_data.concat(data.report['data']);
		        //alert(pop(data.report['data']));
		      },
		      error: function(XMLHttpRequest, textStatus, errorThrown) {
		        //alert("error " + XMLHttpRequest.toString());
		        $('.ahah-progress-throbber').remove();
		        $('#kwresearch-submit-button').show();
		      }
		    });
		  }
		  return false;	
		},
		
		kwresearch_refresh_tax_report: function(vid) {
		  $('.kwresearch-refresh-link-' + vid).replaceWith('<div class="ahah-progress ahah-progress-throbber"><div class="throbber">&nbsp;</div></div>');
		  var data = { 
		    'keywords': $('#edit-taxonomy-tags-' + vid + '-wrapper input').val(),
		    'vid': vid,
			'token' : Drupal.settings.kwresearch.post_token
		  };
		 
		  $.ajax({
		    type: 'POST',
		    url: Drupal.settings.kwresearch.tax_report_callback,
		    data: data,
		    dataType: 'json',
		    success: function(data, textStatus) {
			  vid = data.inputs['vid'];
			  $('#kwresearch-tax-report-'+vid).replaceWith(data.report['output']);
			  $('.ahah-progress-throbber').remove();
		      h = '<a href="#" class="kwresearch-refresh-link-' + vid + '" onclick="kwresearch.kwresearch_refresh_tax_report(\'' + vid + '\'); return false;" title="refresh report">';
		      h += '<img src="' + Drupal.settings.kwresearch.path_to_module + '/icons/refresh.png" alt="refresh report" />';
		      h += '</a>';
		      $('.kwresearch-tax-report-' + vid + ' label').append(h);      
		    },
		    error: function(XMLHttpRequest, textStatus, errorThrown) {
		      alert("error " + errorThrown.toString());
		      $('.ahah-progress-throbber').remove();
		      
		    }
		  });
		  return false;	
		}
	});	

	Drupal.behaviors.kwresearch_init = {
	  attach: function (context, settings) {
		$$.init();
	  }
	}

})(jQuery, kwresearch);

//Implementation of hook_contentanalysis_analysis_success
var kwresearch_contentanalysis_analysis_success = function(aid) {
  kwresearch.kwresearch_process_keywords();
};
jQuery(document).ready(function($){
  var bxsliderProperties = ["mode","speed","slideMargin","startSlide","randomStart","slideSelector","infiniteLoop","hideControlOnEnd","easing","captions","ticker","tickerHover","adaptiveHeight","adaptiveHeightSpeed","video","responsive","useCSS","preloadImages","touchEnabled","swipeThreshold","oneToOneTouch","preventDefaultSwipeX","preventDefaultSwipeY","pager","pagerType","pagerShortSeparator","pagerSelector","pagerCustom","buildPager","controls","nextText","prevText","nextSelector","prevSelector","autoControls","startText","stopText","autoControlsCombine","autoControlsSelector","auto","pause","autoStart","autoDirection","autoHover","autoDelay","minSlides","maxSlides","moveSlides","slideWidth"];
  $('.dexp-shortcode-bxslider').each(function(){
    var $this = $(this);
    var options = {};
    $(bxsliderProperties).each(function(){
      if($this.data(this.toString().toLowerCase()) != 'undefined'){
        options[this.toString()] = $this.data(this.toString().toLowerCase());
      }
    });
    if(!$this.data('controls')){
      options.nextSelector = null;
      options.prevSelector = null;
    }
    var container_width = $this.parents('.view-content').css({position:'relative'}).width();
    var newoptions = adjustOptions(options, container_width);
    //alert(container_width);
    var slide = $this.bxSlider(newoptions);
    $(window).resize(function(){
      var container_width = $this.parents('.view-content').width();
      var newoptions = adjustOptions(options, container_width);
      slide.destroySlider();
      slide = $this.bxSlider(newoptions);
    });
  })
  function adjustOptions(options, container_width){
    var _options = {};
    $.extend(_options, options);
    if((_options.slideWidth*_options.maxSlides + (_options.slideMargin*(_options.maxSlides-1))) < container_width){
      _options.slideWidth = (container_width-(_options.slideMargin*(_options.maxSlides-1)))/_options.maxSlides;
    }else{
      _options.maxSlides = Math.floor((container_width-(_options.slideMargin*(_options.maxSlides-1)))/_options.slideWidth);
      _options.maxSlides = _options.maxSlides == 0?1:_options.maxSlides;
      _options.slideWidth = (container_width-(_options.slideMargin*(_options.maxSlides-1)))/_options.maxSlides;
      //alert(_options.slideWidth)
    }
    return _options;
  }
});;
(function ($) {

Drupal.behaviors.textarea = {
  attach: function (context, settings) {
    $('.form-textarea-wrapper.resizable', context).once('textarea', function () {
      var staticOffset = null;
      var textarea = $(this).addClass('resizable-textarea').find('textarea');
      var grippie = $('<div class="grippie"></div>').mousedown(startDrag);

      grippie.insertAfter(textarea);

      function startDrag(e) {
        staticOffset = textarea.height() - e.pageY;
        textarea.css('opacity', 0.25);
        $(document).mousemove(performDrag).mouseup(endDrag);
        return false;
      }

      function performDrag(e) {
        textarea.height(Math.max(32, staticOffset + e.pageY) + 'px');
        return false;
      }

      function endDrag(e) {
        $(document).unbind('mousemove', performDrag).unbind('mouseup', endDrag);
        textarea.css('opacity', 1);
      }
    });
  }
};

})(jQuery);
;

(function ($) {

/**
 * Auto-hide summary textarea if empty and show hide and unhide links.
 */
Drupal.behaviors.textSummary = {
  attach: function (context, settings) {
    $('.text-summary', context).once('text-summary', function () {
      var $widget = $(this).closest('div.field-type-text-with-summary');
      var $summaries = $widget.find('div.text-summary-wrapper');

      $summaries.once('text-summary-wrapper').each(function(index) {
        var $summary = $(this);
        var $summaryLabel = $summary.find('label').first();
        var $full = $widget.find('.text-full').eq(index).closest('.form-item');
        var $fullLabel = $full.find('label').first();

        // Create a placeholder label when the field cardinality is
        // unlimited or greater than 1.
        if ($fullLabel.length == 0) {
          $fullLabel = $('<label></label>').prependTo($full);
        }

        // Setup the edit/hide summary link.
        var $link = $('<span class="field-edit-link">(<a class="link-edit-summary" href="#">' + Drupal.t('Hide summary') + '</a>)</span>');
        var $a = $link.find('a');
        var toggleClick = true;
        $link.bind('click', function (e) {
          if (toggleClick) {
            $summary.hide();
            $a.html(Drupal.t('Edit summary'));
            $link.appendTo($fullLabel);
          }
          else {
            $summary.show();
            $a.html(Drupal.t('Hide summary'));
            $link.appendTo($summaryLabel);
          }
          toggleClick = !toggleClick;
          return false;
        }).appendTo($summaryLabel);

        // If no summary is set, hide the summary field.
        if ($(this).find('.text-summary').val() == '') {
          $link.click();
        }
      });
    });
  }
};

})(jQuery);
;
(function ($) {

/**
 * Automatically display the guidelines of the selected text format.
 */
Drupal.behaviors.filterGuidelines = {
  attach: function (context) {
    $('.filter-guidelines', context).once('filter-guidelines')
      .find(':header').hide()
      .closest('.filter-wrapper').find('select.filter-list')
      .bind('change', function () {
        $(this).closest('.filter-wrapper')
          .find('.filter-guidelines-item').hide()
          .siblings('.filter-guidelines-' + this.value).show();
      })
      .change();
  }
};

})(jQuery);
;
(function ($) {

/**
 * Toggle the visibility of a fieldset using smooth animations.
 */
Drupal.toggleFieldset = function (fieldset) {
  var $fieldset = $(fieldset);
  if ($fieldset.is('.collapsed')) {
    var $content = $('> .fieldset-wrapper', fieldset).hide();
    $fieldset
      .removeClass('collapsed')
      .trigger({ type: 'collapsed', value: false })
      .find('> legend span.fieldset-legend-prefix').html(Drupal.t('Hide'));
    $content.slideDown({
      duration: 'fast',
      easing: 'linear',
      complete: function () {
        Drupal.collapseScrollIntoView(fieldset);
        fieldset.animating = false;
      },
      step: function () {
        // Scroll the fieldset into view.
        Drupal.collapseScrollIntoView(fieldset);
      }
    });
  }
  else {
    $fieldset.trigger({ type: 'collapsed', value: true });
    $('> .fieldset-wrapper', fieldset).slideUp('fast', function () {
      $fieldset
        .addClass('collapsed')
        .find('> legend span.fieldset-legend-prefix').html(Drupal.t('Show'));
      fieldset.animating = false;
    });
  }
};

/**
 * Scroll a given fieldset into view as much as possible.
 */
Drupal.collapseScrollIntoView = function (node) {
  var h = document.documentElement.clientHeight || document.body.clientHeight || 0;
  var offset = document.documentElement.scrollTop || document.body.scrollTop || 0;
  var posY = $(node).offset().top;
  var fudge = 55;
  if (posY + node.offsetHeight + fudge > h + offset) {
    if (node.offsetHeight > h) {
      window.scrollTo(0, posY);
    }
    else {
      window.scrollTo(0, posY + node.offsetHeight - h + fudge);
    }
  }
};

Drupal.behaviors.collapse = {
  attach: function (context, settings) {
    $('fieldset.collapsible', context).once('collapse', function () {
      var $fieldset = $(this);
      // Expand fieldset if there are errors inside, or if it contains an
      // element that is targeted by the URI fragment identifier.
      var anchor = location.hash && location.hash != '#' ? ', ' + location.hash : '';
      if ($fieldset.find('.error' + anchor).length) {
        $fieldset.removeClass('collapsed');
      }

      var summary = $('<span class="summary"></span>');
      $fieldset.
        bind('summaryUpdated', function () {
          var text = $.trim($fieldset.drupalGetSummary());
          summary.html(text ? ' (' + text + ')' : '');
        })
        .trigger('summaryUpdated');

      // Turn the legend into a clickable link, but retain span.fieldset-legend
      // for CSS positioning.
      var $legend = $('> legend .fieldset-legend', this);

      $('<span class="fieldset-legend-prefix element-invisible"></span>')
        .append($fieldset.hasClass('collapsed') ? Drupal.t('Show') : Drupal.t('Hide'))
        .prependTo($legend)
        .after(' ');

      // .wrapInner() does not retain bound events.
      var $link = $('<a class="fieldset-title" href="#"></a>')
        .prepend($legend.contents())
        .appendTo($legend)
        .click(function () {
          var fieldset = $fieldset.get(0);
          // Don't animate multiple times.
          if (!fieldset.animating) {
            fieldset.animating = true;
            Drupal.toggleFieldset(fieldset);
          }
          return false;
        });

      $legend.append(summary);
    });
  }
};

})(jQuery);
;
/*! http://mths.be/placeholder v2.0.8 by @mathias */
;(function(window, document, $) {

	// Opera Mini v7 doesn’t support placeholder although its DOM seems to indicate so
	var isOperaMini = Object.prototype.toString.call(window.operamini) == '[object OperaMini]';
	var isInputSupported = 'placeholder' in document.createElement('input') && !isOperaMini;
	var isTextareaSupported = 'placeholder' in document.createElement('textarea') && !isOperaMini;
	var prototype = $.fn;
	var valHooks = $.valHooks;
	var propHooks = $.propHooks;
	var hooks;
	var placeholder;

	if (isInputSupported && isTextareaSupported) {

		placeholder = prototype.placeholder = function() {
			return this;
		};

		placeholder.input = placeholder.textarea = true;

	} else {

		placeholder = prototype.placeholder = function() {
			var $this = this;
			$this
				.filter((isInputSupported ? 'textarea' : ':input') + '[placeholder]')
				.not('.placeholder')
				.bind({
					'focus.placeholder': clearPlaceholder,
					'blur.placeholder': setPlaceholder
				})
				.data('placeholder-enabled', true)
				.trigger('blur.placeholder');
			return $this;
		};

		placeholder.input = isInputSupported;
		placeholder.textarea = isTextareaSupported;

		hooks = {
			'get': function(element) {
				var $element = $(element);

				var $passwordInput = $element.data('placeholder-password');
				if ($passwordInput) {
					return $passwordInput[0].value;
				}

				return $element.data('placeholder-enabled') && $element.hasClass('placeholder') ? '' : element.value;
			},
			'set': function(element, value) {
				var $element = $(element);

				var $passwordInput = $element.data('placeholder-password');
				if ($passwordInput) {
					return $passwordInput[0].value = value;
				}

				if (!$element.data('placeholder-enabled')) {
					return element.value = value;
				}
				if (value == '') {
					element.value = value;
					// Issue #56: Setting the placeholder causes problems if the element continues to have focus.
					if (element != safeActiveElement()) {
						// We can't use `triggerHandler` here because of dummy text/password inputs :(
						setPlaceholder.call(element);
					}
				} else if ($element.hasClass('placeholder')) {
					clearPlaceholder.call(element, true, value) || (element.value = value);
				} else {
					element.value = value;
				}
				// `set` can not return `undefined`; see http://jsapi.info/jquery/1.7.1/val#L2363
				return $element;
			}
		};

		if (!isInputSupported) {
			valHooks.input = hooks;
			propHooks.value = hooks;
		}
		if (!isTextareaSupported) {
			valHooks.textarea = hooks;
			propHooks.value = hooks;
		}

		$(function() {
			// Look for forms
			$(document).delegate('form', 'submit.placeholder', function() {
				// Clear the placeholder values so they don't get submitted
				var $inputs = $('.placeholder', this).each(clearPlaceholder);
				setTimeout(function() {
					$inputs.each(setPlaceholder);
				}, 10);
			});
		});

		// Clear placeholder values upon page reload
		$(window).bind('beforeunload.placeholder', function() {
			$('.placeholder').each(function() {
				this.value = '';
			});
		});

	}

	function args(elem) {
		// Return an object of element attributes
		var newAttrs = {};
		var rinlinejQuery = /^jQuery\d+$/;
		$.each(elem.attributes, function(i, attr) {
			if (attr.specified && !rinlinejQuery.test(attr.name)) {
				newAttrs[attr.name] = attr.value;
			}
		});
		return newAttrs;
	}

	function clearPlaceholder(event, value) {
		var input = this;
		var $input = $(input);
		if (input.value == $input.attr('placeholder') && $input.hasClass('placeholder')) {
			if ($input.data('placeholder-password')) {
				$input = $input.hide().next().show().attr('id', $input.removeAttr('id').data('placeholder-id'));
				// If `clearPlaceholder` was called from `$.valHooks.input.set`
				if (event === true) {
					return $input[0].value = value;
				}
				$input.focus();
			} else {
				input.value = '';
				$input.removeClass('placeholder');
				input == safeActiveElement() && input.select();
			}
		}
	}

	function setPlaceholder() {
		var $replacement;
		var input = this;
		var $input = $(input);
		var id = this.id;
		if (input.value == '') {
			if (input.type == 'password') {
				if (!$input.data('placeholder-textinput')) {
					try {
						$replacement = $input.clone().attr({ 'type': 'text' });
					} catch(e) {
						$replacement = $('<input>').attr($.extend(args(this), { 'type': 'text' }));
					}
					$replacement
						.removeAttr('name')
						.data({
							'placeholder-password': $input,
							'placeholder-id': id
						})
						.bind('focus.placeholder', clearPlaceholder);
					$input
						.data({
							'placeholder-textinput': $replacement,
							'placeholder-id': id
						})
						.before($replacement);
				}
				$input = $input.removeAttr('id').hide().prev().attr('id', id).show();
				// Note: `$input[0] != input` now!
			}
			$input.addClass('placeholder');
			$input[0].value = $input.attr('placeholder');
		} else {
			$input.removeClass('placeholder');
		}
	}

	function safeActiveElement() {
		// Avoid IE9 `document.activeElement` of death
		// https://github.com/mathiasbynens/jquery-placeholder/pull/99
		try {
			return document.activeElement;
		} catch (exception) {}
	}

}(this, document, jQuery));
;
(function ($) {

  Drupal.form_placeholder = {};

  Drupal.form_placeholder.elementIsSupported = function ($element) {
    return $element.is('input[type=text], input[type=date], input[type=email], input[type=url], input[type=tel], input[type=password], textarea');
  };

  Drupal.form_placeholder.placeholderIsSupported = function () {
    // Opera Mini v7 doesn’t support placeholder although its DOM seems to
    // indicate so.
    var isOperaMini = Object.prototype.toString.call(window.operamini) == '[object OperaMini]';
    return 'placeholder' in document.createElement('input') && !isOperaMini;
  };

  Drupal.behaviors.form_placeholder = {
    attach: function (context, settings) {
      // In some cases settings after ajax form submit could contain only
      // settings from response but not all Drupal.settings data.
      if (!settings.hasOwnProperty('form_placeholder')) {
        settings = Drupal.settings;
      }
      var include = settings.form_placeholder.include;
      if (include) {
        include += ', ';
      }
      include += '.form-placeholder-include-children *';
      include += ', .form-placeholder-include';
      var exclude = settings.form_placeholder.exclude;
      if (exclude) {
        exclude += ', ';
      }
      exclude += '.form-placeholder-exclude-children *';
      exclude += ', .form-placeholder-exclude';
      exclude += ', .form-placeholder-processed';

      var required_indicator = settings.form_placeholder.required_indicator;

      $(include).not(exclude).each(function () {
        var $textfield = $(this);
        var elementSupported = Drupal.form_placeholder.elementIsSupported($textfield);
        var placeholderSupported = Drupal.form_placeholder.placeholderIsSupported();

        // Check if element support placeholder attribute.
        if (!elementSupported) {
          return;
        }
        // Placeholder is supported.
        else if (placeholderSupported || settings.form_placeholder.fallback_support) {
          var $form = $textfield.closest('form');
          var $label = $form.find('label[for=' + this.id + ']');

          if (required_indicator === 'append') {
            $label.find('.form-required').insertAfter($textfield).prepend('&nbsp;');
          }
          else if (required_indicator === 'remove') {
            $label.find('.form-required').remove();
          }
          else if (required_indicator === 'text') {
            $label.find('.form-required').text('(' + Drupal.t('required') + ')');
          }

          if (!$textfield.attr('placeholder')) {
            $textfield.attr('placeholder', $.trim($label.text()));
            $label.addClass('element-invisible');
          }

          // Fallback support for older browsers.
          if (!placeholderSupported && settings.form_placeholder.fallback_support) {
            $textfield.placeholder();
          }
          $textfield.addClass('form-placeholder-processed');
        }
      });
    }
  };

})(jQuery);
;
/**
 * @file
 * Attaches behaviors for the Chosen module.
 */

(function($) {
  Drupal.behaviors.chosen = {
    attach: function(context, settings) {
      settings.chosen = settings.chosen || Drupal.settings.chosen;

      // Prepare selector and add unwantend selectors.
      var selector = settings.chosen.selector;

      // Function to prepare all the options together for the chosen() call.
      var getElementOptions = function (element) {
        var options = $.extend({}, settings.chosen.options);

        // The width default option is considered the minimum width, so this
        // must be evaluated for every option.
        if (settings.chosen.minimum_width > 0) {
          if ($(element).width() < settings.chosen.minimum_width) {
            options.width = settings.chosen.minimum_width + 'px';
          }
          else {
            options.width = $(element).width() + 'px';
          }
        }

        // Some field widgets have cardinality, so we must respect that.
        // @see chosen_pre_render_select()
        if ($(element).attr('multiple') && $(element).data('cardinality')) {
          options.max_selected_options = $(element).data('cardinality');
        }

        return options;
      };

      // Process elements that have opted-in for Chosen.
      // @todo Remove support for the deprecated chosen-widget class.
      $('select.chosen-enable, select.chosen-widget', context).once('chosen', function() {
        options = getElementOptions(this);
        $(this).chosen(options);
      });

      $(selector, context)
        // Disabled on:
        // - Field UI
        // - WYSIWYG elements
        // - Tabledrag weights
        // - Elements that have opted-out of Chosen
        // - Elements already processed by Chosen.
        .not('#field-ui-field-overview-form select, #field-ui-display-overview-form select, .wysiwyg, .draggable select[name$="[weight]"], .draggable select[name$="[position]"], .chosen-disable, .chosen-processed')
        .filter(function() {
          // Filter out select widgets that do not meet the minimum number of
          // options.
          var minOptions = $(this).attr('multiple') ? settings.chosen.minimum_multiple : settings.chosen.minimum_single;
          if (!minOptions) {
            // Zero value means no minimum.
            return true;
          }
          else {
            return $(this).find('option').length >= minOptions;
          }
        })
        .once('chosen', function() {
          options = getElementOptions(this);
          $(this).chosen(options);
        });
    }
  };
})(jQuery);
;
